
/* global firebase */

var helloApp = angular.module("HelloApp", ["firebase"]);

helloApp.config(function () {
    var config = {
        
        // ...

    };
    firebase.initializeApp(config);
});


helloApp.service("Firebase", function ($firebaseObject) {

    // ...

});


helloApp.controller("HelloCtrl", function ($scope, Firebase) {

    // ...

});

