
// ---------------------------------------
// Web-selainohjelmointi
// Tehtävä 4.6
// ---------------------------------------
var OPISKELIJA = {
    nimi: 'N.N.',
    numero: '999999'
};
// --------------------------------------- 


/* global TypeApp, TEXT, TIME */

var TypeApp = angular.module('TypeApp', []);

TypeApp.controller('TypeController', function ($interval, $scope) {

    // globaalit muuttujat TEXT ja TIME 
    // asetetaan tiedostossa index.html

    $scope.text = TEXT;
    var counter = null;

    // ...

});

