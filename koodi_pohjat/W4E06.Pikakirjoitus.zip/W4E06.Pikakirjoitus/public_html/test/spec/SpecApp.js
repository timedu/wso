
/* global expect, OPISKELIJA */

var
        APP = 'TypeApp',
        CONTROLLER = 'TypeController',
        TEMPLATE = '../tmpl/template.html';

var TEXT = 'Lorem ipsum dolor sit amet, ...';
var TIME = 3;

describe(APP + ' / ' + OPISKELIJA.nimi, function () {

    var templateHtml;

    beforeAll(function () {
        templateHtml = $.ajax(TEMPLATE, {async: false}).responseText;
    });

    describe('template', function () {
        it('sisältää oletetut elementit', function () {
            var template = $(templateHtml);
            expect(template.find('p').length).toBe(4);
            expect(template.find('p>textarea').length).toBe(1);
            expect(template.find('p>button').length).toBe(1);
            expect(template.find('*').length).toBe(6);
        });
    });

    describe('view', function () {

        var scope, controller, tpl;


        beforeEach(function () {

            module(APP);

            inject(function ($compile, $rootScope, $controller) {

                scope = $rootScope.$new();
                tpl = $compile($(templateHtml))(scope);
                controller = $controller(CONTROLLER, {
                    $scope: scope
                });
            });

        });

        it('esittää kirjoitettavan tekstin', function () {

            scope.$digest();

            var teksti = $(tpl.find('p')[0]).text();
            expect(teksti).toBe(TEXT);
        });

        it('ottaa tekstialueelle oikean merkin', function () {

            scope.$digest();

            var area = tpl.find('textarea');

            area.val('L').trigger('input');

            expect(area.val()).toBe('L');
        });

        it('ei ota tekstialueelle väärää merkkiä', function () {

            scope.$digest();

            var area = tpl.find('textarea');

            area.val('x').trigger('input');

            expect(area.val()).toBe('');
        });

        it('tyhjentää tekstialueen ja esittää peliajan pelin alussa', function () {

            scope.$digest();

            TIME = 0.2;

            var area = tpl.find('textarea');
            var button = tpl.find('button');
            var p2 = $(tpl.find('p')[2]);


            area.val('L').trigger('input');
            button.trigger('click');

            expect(area.val()).toBe('');
            expect(p2.text()).toBe('Aikaa jäljellä: ' + TIME);

        });

        xdescribe('TARKASTA SOVELLUSTA AJAMALLA', function () {
            it('askeltaa aikaa pelin ollessa käynnissä', function () {
                expect(true).toBe(true);
            });

            it('ilmoittaa tuloksen pelin päätyttyä', function () {
                expect(true).toBe(true);
            });
        });

    });

});

