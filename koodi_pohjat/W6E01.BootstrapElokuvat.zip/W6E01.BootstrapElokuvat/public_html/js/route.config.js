

MovieApp.config(function ($routeProvider) {
    $routeProvider
            .when('/movies', {
                controller: 'ListController',
                templateUrl: 'todo/list.movies.html'
            })
            .when('/movies/new', {
                controller: 'NewController',
                templateUrl: 'todo/new.movie.html'
            })
            .when('/movies/:id', {
                controller: 'ShowController',
                templateUrl: 'view/show.movie.html'
            })
            .otherwise({
                redirectTo: '/movies'
            });
});

