

/* global MovieApp */

MovieApp.controller('ListController', function ($scope, MovieService, $location) {

    $scope.movies = MovieService.getMovies();

    /*
     * haun käsittely
     */

    var NOT_EXISTS = Math.random();
    $scope.search = {}; // hakuehdot
    $scope.search.name = NOT_EXISTS; 

    $scope.searchMovies = function () {
        if ($scope.name || $scope.release) { // hakukentät
            $scope.search.name = $scope.name;
            $scope.search.release = $scope.release;
        } else {
            // jos hakukenttiä ei täytetä, asetetaan 
            // haku arvoon, joka ei toteudu
            $scope.search.name = NOT_EXISTS;
        }
    };

    $scope.add = function () {
        $location.path('/movies/new');
    };

    $scope.remove = function (id) {
        MovieService.removeMovie(id);
        $scope.movies = MovieService.getMovies();
    };

});


MovieApp.controller('NewController', function ($scope, MovieService, $location) {

    $scope.add = function () {

        MovieService.addMovie(
                $scope.name,
                $scope.director,
                $scope.release,
                $scope.description);
                
       $location.path('/movies');      
    };

});


MovieApp.controller('ShowController', function ($scope, MovieService, $routeParams) {

    $scope.movie = MovieService.getMovie($routeParams.id);

});

