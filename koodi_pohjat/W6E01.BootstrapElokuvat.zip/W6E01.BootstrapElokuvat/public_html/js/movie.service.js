
/* global MovieApp */

MovieApp.service('MovieService', function (MovieData) {

    var movies = MovieData;

    this.getMovies = function () {
        movies.forEach(function (movie, index) {
            movie.id = index;
        });
        return movies;
    };

    this.getMovie = function (id) {
        return movies[id];
    };

    this.addMovie = function (name, director, release, description) {
        movies.push({
            name: name,
            director: director,
            release: release,
            description: description
        });
    };

    this.removeMovie = function(id) {
        movies.splice(id,1);
    };

});



MovieApp.value('MovieData', [
    {
        name: 'Honey, I Shrunk the Kids',
        link: 'http://www.imdb.com/title/tt0097523',
        release: '1989',
        description: 'The scientist father of a teenage girl and boy accidentally shrinks his and two other neighborhood teens to the size of insects. Now the teens must fight diminutive dangers as the father searches for them.',
        director: 'Joe Johnston'
    },
    {
        name: 'The Lord of the Rings: The Fellowship of the Ring',
        link: 'http://www.imdb.com/title/tt0120737',
        release: '2001',
        description: 'A meek hobbit of the Shire and eight companions set out on a journey to Mount Doom to destroy the One Ring and the dark lord Sauron.',
        director: 'Peter Jackson'
    },
    {
        name: 'My Neighbor Totoro',
        link: 'http://www.imdb.com/title/tt0096283',
        release: '1988',
        description: 'When two girls move to the country to be near their ailing mother, they have adventures with the wonderous forest spirits who live nearby.',
        director: 'Hayao Miyazaki'
    }
]);
