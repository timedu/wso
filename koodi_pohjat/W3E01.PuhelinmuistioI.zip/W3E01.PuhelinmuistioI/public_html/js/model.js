
"use strict";

var muistio = muistio || {};

muistio.initModel = function(model, view) {
    // ei alustettavaa
};

muistio.Model = function () {

    var henkilot = {};

    this.annaNumerot = function (nimi) {
        
        // ...
        
    };

    this.lisaaNumero = function (nimi, numero) {
        
        // ...

    };

    this.poistaNumero = function (nimi, numero) {
        
        // ...

    };

};


