
/* global expect */

var
        APP = 'MovieApp',
        CONTROLLER = 'MovieController',
        TEMPLATE = '../todo/template.html';

describe(APP, function () {

    var templateHtml;

    beforeAll(function () {
        templateHtml = $.ajax(TEMPLATE, {async: false}).responseText;
    });

    describe('template', function () {

        var template;

        beforeAll(function () {
            template = $(templateHtml);
        });

        it('sisältää yhden div-elementin, joka on templatessa ylimpänä', function () {

            expect(template.find('div').length).toBe(1);
            expect(template.find('*:first').prop('tagName')).toBe('DIV');
            expect(template.find('div').siblings().length).toBe(0);
        });

        it('sisältää yhden h3-elementin', function () {

            expect(template.find('h3').length).toBe(1);
        });

        it('sisältää yhden a-elementin, joka on h3-elementin sisältönä', function () {

            expect(template.find('a').length).toBe(1);
            expect(template.find('h3>a').length).toBe(1);
        });

        it('sisältää kolme h4-elementiä sisältäen määrätyt tekstit', function () {

            expect(template.find('h4').length).toBe(3);

            expect($(template.find('h4')[0]).text()).toContain('Director');
            expect($(template.find('h4')[1]).text()).toContain('Oscar awards');
            expect($(template.find('h4')[2]).text()).toContain('Roles');
        });

        it('sisältää kaksi p-elementtiä', function () {

            expect(template.find('p').length).toBe(2);
        });

        it('sisältää kaksi yksi-jäsenistä numeroimatonta luetteloa', function () {

            expect(template.find('ul').length).toBe(2);
            expect(template.find('li').length).toBe(2);
            expect(template.find('ul>li').length).toBe(2);
        });


    });

    describe('view', function () {

        var scope, controller, cTemplate;

        beforeEach(function () {

            module(APP);

            inject(function ($compile, $rootScope, $controller) {

                scope = $rootScope.$new();
                cTemplate = $compile($(templateHtml))(scope);
                controller = $controller(CONTROLLER, {
                    $scope: scope
                });
            });

            scope.$digest();
        });

        it('sisältää ylätasolla kolme div-elementtiä (yksi kullekin elokuvalle)', function () {

            expect(cTemplate.find('div').length).toBe(3);
            expect(cTemplate.find('*:first').prop('tagName')).toBe('DIV');
            expect(cTemplate.find('div:first').siblings('div').length).toBe(2);
        });



        describe('esittää elokuvan "Lord of the Rings" tiedot odotetusti', function () {

            var movie;

            beforeAll(function () {

                movie = cTemplate.find("h3:contains('Lord of the Rings')").parent('div');
            });

            it('elokuvan nimen sisältämä otsikko on div-elementin sisältönä', function () {
                expect(movie.length).toBe(1);
            });

            it('elokuvan nimi on imdb-palveluun osoittava linkki', function () {
                
                var linkki = movie.find("a:contains('Lord of the Rings')");
                
                expect(linkki.length).toBe(1);
                expect(linkki.attr('href')).toBe('http://www.imdb.com/title/tt0120737');
            });

            it('elokuvan ohjaaja on "Peter Jackson" ', function () {
                
                var ohjaaja = movie.find("h4:contains('Director')").next('p');
                
                expect(ohjaaja.length).toBe(1);
                expect(ohjaaja.text()).toContain('Peter Jackson');
            });

            it('elokuva on saanut neljä Oskaria', function () {                

                var otsikko = movie.find("h4:contains('Oscar awards')");
                
                expect(otsikko.length).toBe(1);                                
                expect(otsikko.text()).toContain('4');
                
                var luettelo = otsikko.next('ul');
                
                expect(luettelo.find('li').length).toBe(4);
                expect(luettelo.text()).toContain('Best Music');
            });

            it('elokuvalla on kuusi näyttelijää keskeisissä rooleissa', function () {                

                var otsikko = movie.find("h4:contains('Roles')");
                
                expect(otsikko.length).toBe(1);                                
                
                var luettelo = otsikko.next('ul');
                
                expect(luettelo.find('li').length).toBe(6);
                expect(luettelo.text()).toContain('Sean Astin');
                expect(luettelo.text()).toContain('Aragorn');
            });

        });

        it('esittää elokuvat julkaisuvuoden (h3-otsikossa) mukaisessa \n\
järjestyksessä; tuorein ensin', function () {

            expect(cTemplate.find('h3').length).toBe(3);

            expect($(cTemplate.find('h3')[0]).text()).toContain('(2001)');
            expect($(cTemplate.find('h3')[1]).text()).toContain('(1989)');
            expect($(cTemplate.find('h3')[2]).text()).toContain('(1988)');
        });

        it('jättää esittämättä Oscar-otsikon (ja siihen liittyvän luettelon), \n\
jos elokuva ei ole saanut yhtään Oskaria', function () {

            var otsikot = cTemplate.find("h4:contains('Oscar awards')");
            var luettelot = otsikot.next('ul');

            expect(otsikot.length).toBe(1);
            expect(luettelot.length).toBe(1);
        });
        
    });

});

