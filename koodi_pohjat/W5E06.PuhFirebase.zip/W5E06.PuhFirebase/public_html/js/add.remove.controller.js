
/* global PuhApp */

"use strict";

PuhApp.controller('AddController', function ($scope, Muistio, $location, $routeParams) {

    // kontrollerin sisällön voi kopioida ilman muutoksia
    // tehtävän 5.4 ratkaisusta (controller.js)

});


PuhApp.controller('RemoveController', function ($scope, Muistio, $location, $routeParams) {

    // kontrollerin sisällön voi kopioida ilman muutoksia
    // tehtävän 5.4 ratkaisusta (controller.js)

});

