
/* global firebase */

var PuhApp = angular.module('PuhApp', ['ngRoute', 'firebase']);


PuhApp.config(function () {

// Perustamasi Firebase-projektin tunnisteet

//    firebase.initializeApp({
//        apiKey: "...",
//        authDomain: "...",
//        databaseURL: "...",
//        storageBucket: "...",
//        messagingSenderId: "..."
//    });

});


PuhApp.constant('FIREBASE_USER', {
        
// Firebase-projektiin määrittelemäsi käyttäjä
// (firebase.auth.service.js käyttää tätä)
    
    email: '...',
    password: '...' 
    
});


// Painonappi-direktiivin käyttämät otsikkotiedot
// (ks. button.directive.js))

PuhApp.constant('WSO_BTN', {
    add: 'Lisää',
    remove: 'Poista',
    cancel: 'Peruuta'
});


PuhApp.run(function ($rootScope, Auth, $location) {

    // Yleisellä näkyvyysalueella olevat käyttäjän tunnistautumiseen
    // liittyvät funktiot:
    // 
    // - logUserIn()    : kirjautuminen Firebaseen
    // - logUserAuth()  : kirjautuminen ulos Firebasesta
    //
    // (search.view.html käyttää näitä)

    $rootScope.logUserIn = Auth.logUserIn;
    $rootScope.logUserOut = Auth.logUserOut;

    
    // Kirjautuneen käyttäjän ylläpito yleisen näkyvyysalueen 
    // muuttujassa 'userLoggedIn' (search.view.html käyttää tätä);
    // käyttäjän kirjautuessa ulos, siirrytään sovelluksen juureen
    // ja lähetetään 'logout' -viesti (search.controller.js ja
    // firebase.db.service.js reagoivat tähän viestiin)
        
    Auth.onUserLog(function (user) {
        $rootScope.userLoggedIn = !!user;
        !user && $location.path('/');
        !user && $rootScope.$broadcast('logout');
        console.log('User signed', user ? 'in.' : 'out.');
    });


    // Reititys sovelluksen juureen, jos pyritään osoitteeseen, johon
    // ei sallita pääsyä ilman tunnistautumista (tässä reagoitava tilanteen
    // aikaansaa tiedostoissa route.config.js ja firebase.auth.service.js)

    $rootScope.$on("$routeChangeError", function (event, next, previous, error) {
        console.log(error);
        if (error === "AUTH_REQUIRED") {
            $location.path("/");
        }
    });

});

