

/* global PuhApp */

PuhApp.service('Auth', function ($firebaseAuth, FIREBASE_USER) {

    var auth = $firebaseAuth();

    this.onUserLog = auth.$onAuthStateChanged;

    this.logUserIn = function () {
        auth.$signInWithEmailAndPassword(
                FIREBASE_USER.email,
                FIREBASE_USER.password)
                .catch(function (error) {
                    console.log("Login failed",
                            error.code, error.message);
                });
    };

    this.logUserOut = function () {
        auth.$signOut();
    };

    this.checkLoggedIn = function () {
        return auth.$requireSignIn();
    };

});
