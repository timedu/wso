
/* global PuhApp, Function */

PuhApp.directive('wsoBtn', function (WSO_BTN ) {

    return {
        link: function (scope, elem, attrs) {

        // kopioi tämän tiedoston tilalle tehtävän 5.4 ratkaisusta
        // sisältö tiedostosta directive.js

        }
    };
});