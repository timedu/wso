
"use strict";

PuhApp.config(function ($routeProvider) {
        
    // lähtökohdaksi tehtävän 5.4 ratkaisun koodi (config.js);
    // muokkaus siten, että ainoastaan juureen ('/') pääsee 
    // tunnistautumatta            
            
});

