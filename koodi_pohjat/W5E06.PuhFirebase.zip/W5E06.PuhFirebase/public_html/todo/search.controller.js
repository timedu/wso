
/* global PuhApp */

"use strict";

PuhApp.controller('SearchController', function ($scope, Muistio, $routeParams) {


    // ...
    
    
    // sivun tietojen poisto käyttäjän kirjaituessa ulos Firebasesta

    $scope.$on('logout', function () {
        $scope.nimi = undefined;
        $scope.numerot = {};
    });

});

