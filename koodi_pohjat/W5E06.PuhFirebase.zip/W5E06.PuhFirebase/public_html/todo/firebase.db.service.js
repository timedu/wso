

/* global PuhApp, firebase */

PuhApp.service('Muistio', function ($firebaseObject, $rootScope) {


    var ref = firebase.database().ref();
    var puh; // $firebaseObject


    this.annaNumerot = function (nimi, done) {
        
        // tähän alkuun firebase-objektin luonti, jos sitä
        // ei ole olemassa tai se on merkitty tuhotuksi
        // (vrt. lopussa oleva logout-tilanteessa suoritettava
        // koodi)
                
        // ...
    };

    this.lisaaNumero = function (nimi, numero) {
        
        // ...
    };

    this.poistaNumero = function (nimi, numero) {
        
        // ...
    };


    // Virhetilanteiden käsittely; voidaan hyödyntää
    // Firebase-käsittelyn (edellä olevat kolme metodia)
    // 'catch'-haarassa
    
    function handleError(error) {
        console.log("Operation failed",
                error.code, error.message);
    }


    // Resurssien vapautus uloskirjautumisen yhteydessä;  
    // 'logout'-viestin lähettää tiedostossa 'app.js'
    // oleva koodi
        
    $rootScope.$on('logout', function () {
        //console.log('Muistio/onLogout');
        if (puh !== undefined && !puh.$isDestroyed) {
            puh.$destroy();
        }
    });


});

