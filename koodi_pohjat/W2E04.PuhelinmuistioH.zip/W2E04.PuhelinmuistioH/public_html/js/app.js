
"use strict";

/* global muistio */

var muistio = muistio || {};

/*
 * -------------------------------------------------------------------- *
 * Sovelluksen alustaja                                                 *
 * -------------------------------------------------------------------- *
 * - muodostaa mallin ja näkymän                                        *
 * - määrittelee kontrollerina toimivat tapahtumakäsittelijät           *
 * -------------------------------------------------------------------- *
 */

muistio.init = function () {

    /*
     * Malli
     * ----------------------------------------------------------------
     */


    /*
     * Näkymä
     * ----------------------------------------------------------------
     */

    // näkymän käsittelemät elementissä html-dokumentissa
    
    /*
     * Tapahtumakäsittelijät ("kontrolleri")
     * ----------------------------------------------------------------
     */

    // syötekentät, joista "kontrolleri" poimii tiedot


    // numeroiden haku 
    
    
    // numeron lisäys
        

    // numeron poisto


    // - näkymä rakentaa ajon aikana poisto-nappeja ja määrittelee
    //   niiden click-tapahtumien käsittelijäksi tässä parametrina 
    //   annetun funktion
    

};



/*
 * -------------------------------------------------------------------- *
 * Sovelluksen mallin muodostin                                         *
 * -------------------------------------------------------------------- *
 * - malli sisältää datan ja sitä käsittelevät metodit                  *
 * -------------------------------------------------------------------- *
 */

/*
 * +------------------------------------+
 * | MODEL                              |
 * +------------------------------------+
 * | - henkilot = {}                    |                      
 * +------------------------------------+
 * | + annaNumerot(nimi)                |
 * | + lisaaNumero(nimi, numero)        |
 * | + poistaNumero(nimi, numero)       |
 * +------------------------------------+
 */

muistio.Model = function () {



};



