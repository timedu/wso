
/* global muistio, expect, Function */


/*
 * -------------------------------------------------------------------------
 * Rakenne
 * -------------------------------------------------------------------------
 */

describe('Puhelinmuistio - View (rakenne):', function () {

    var view = new muistio.View();

    //

    it('muodostimen prototyyppi-attribuutilla ei ole ominaisuuksia', function () {
        expect(Object.keys(muistio.View.prototype).length).toEqual(0);
    });

    // 

    it('oliolla on asetaSpanNimi -metodi', function () {
        expect(view.hasOwnProperty('asetaSpanNimi') && view.asetaSpanNimi instanceof Function).toBeTruthy();
    });

    it('oliolla on asetaUlNumerot -metodi', function () {
        expect(view.hasOwnProperty('asetaUlNumerot') && view.asetaUlNumerot instanceof Function).toBeTruthy();
    });

    it('oliolla on asetaPoistonKasittelija -metodi', function () {
        expect(view.hasOwnProperty('asetaPoistonKasittelija') && view.asetaPoistonKasittelija instanceof Function).toBeTruthy();
    });

    it('oliolla on paivita -metodi', function () {
        expect(view.hasOwnProperty('paivita') && view.paivita instanceof Function).toBeTruthy();
    });

    // 

    it('oliolla ei ole metodien lisäksi muita ominaisuuksia', function () {
        expect(Object.keys(view).length).toEqual(4);
    });

});


describe('Puhelinmuistio - View (toiminta):', function () {

    /*
     * Testikäyttöliittymä
     */
    
    var span = document.createElement('span');
    var ul = document.createElement('ul');

    /*
     * Testauksen kohde: muistio.View
     */

    var view;

    beforeEach(function () {
        view = new muistio.View();
        view.asetaSpanNimi(span);
        view.asetaUlNumerot(ul);
        // 
        span.textContent = '';
        ul.innerHTML = '';
    });

    /*
     * Testit
     */

    it('päivittää nimen käyttöliittymään', function () {

        var nimi = 'bart';
        var numerot = [];

        view.paivita(nimi, numerot);

        expect(span.textContent).toEqual('bart');
        expect(ul.querySelectorAll('*').length).toEqual(0);
    });

    it('rakentaa li-elementit puhelinnumeroille', function () {

        var nimi = '';
        var numerot = ['111', '333'];
        view.paivita(nimi, numerot);

        expect(ul.querySelectorAll('li').length).toEqual(2);                
    });


    it('esittää puhelinnumerot li-elementeissä', function () {

        var nimi = '';
        var numerot = ['111', '333'];

        view.paivita(nimi, numerot);

        expect(ul.querySelector('li:first-child').textContent.substr(0,3)).toEqual('111');
        expect(ul.querySelector('li:last-child').textContent.substr(0,3)).toEqual('333');                
    });


    it('rakentaa poisto-napit li-elementteihin', function () {

        var nimi = '';
        var numerot = ['111', '333'];
        view.paivita(nimi, numerot);

        expect(ul.querySelectorAll('li button').length).toEqual(2);
    });


    it('asettaa poisto-napille click-tapahtuman käsittelijän', function () {

        var nimi = '';
        var numerot = ['111'];
        var f = function () {}; 

        view.asetaPoistonKasittelija(f);
        view.paivita(nimi, numerot);

        expect(ul.querySelector('li button').onclick).toEqual(f);
    });


    it('otsikoi poistonapit "X"-merkillä', function () {

        var nimi = '';
        var numerot = ['111', '333'];

        view.paivita(nimi, numerot);

        expect(ul.querySelector('li:first-child').textContent.substr(3)).toEqual('X');
        expect(ul.querySelector('li:last-child').textContent.substr(3)).toEqual('X');
                
    });



});
