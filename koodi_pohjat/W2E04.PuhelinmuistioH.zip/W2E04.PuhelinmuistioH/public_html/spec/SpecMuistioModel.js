

/* global muistio, expect, Function */

/*
 * -------------------------------------------------------------------------
 * Rakenne
 * -------------------------------------------------------------------------
 */

describe('Puhelinmuistio - Model (rakenne):', function () {

    var model = new muistio.Model();

    //

    it('muodostimen prototyyppi-attribuutilla ei ole ominaisuuksia', function () {
        expect(Object.keys(muistio.Model.prototype).length).toEqual(0);
    });

    // 

    it('oliolla on annaNumerot -metodi', function () {
        expect(model.hasOwnProperty('annaNumerot') && model.annaNumerot instanceof Function).toBeTruthy();
    });

    it('oliolla on lisaaNumero -metodi', function () {
        expect(model.hasOwnProperty('lisaaNumero') && model.lisaaNumero instanceof Function).toBeTruthy();
    });

    it('oliolla on poistaNumero -metodi', function () {
        expect(model.hasOwnProperty('poistaNumero') && model.poistaNumero instanceof Function).toBeTruthy();
    });

    // 

    it('oliolla ei ole metodien lisäksi muita ominaisuuksia', function () {
        expect(Object.keys(model).length).toEqual(3);
    });

});

/*
 * -------------------------------------------------------------------------
 * Toiminta
 * -------------------------------------------------------------------------
 */

describe('Puhelinmuistio - Model (toiminta):', function () {

    /*
     * Testidata
     * ----------------------------------------------
     */

    var nimi_1 = 'mikke';
    var numero_11 = '044-33669933';
    var numero_12 = '231';

    var nimi_2 = 'matti';
    var numero_21 = '1111';

    var nimi_eioo = 'jaakko';
    var numero_eioo = '333';

    /*
     * Testattava malli
     * ----------------------------------------------
     */

    var model;

    beforeEach(function () {
        model = new muistio.Model();
    });

    /*
     * Numeroiden lisäys
     * ----------------------------------------------
     */

    it('lisää numeron henkilölle', function () {

        model.lisaaNumero(nimi_1, numero_11);

        expect(model.annaNumerot(nimi_1).length).toEqual(1);
        expect(model.annaNumerot(nimi_1)).toContain(numero_11);
    });

    it('ei lisää samaa numeroa kahteen kertaan', function () {

        model.lisaaNumero(nimi_1, numero_11);
        model.lisaaNumero(nimi_1, numero_11);

        expect(model.annaNumerot(nimi_1).length).toEqual(1);
    });

    it('lisää henkilölle useita numeroita', function () {

        model.lisaaNumero(nimi_1, numero_11);
        model.lisaaNumero(nimi_1, numero_12);

        expect(model.annaNumerot(nimi_1).length).toEqual(2);
        expect(model.annaNumerot(nimi_1)).toContain(numero_11);
        expect(model.annaNumerot(nimi_1)).toContain(numero_12);
    });

    it('ei lisää henkilön numeroa toiselle henkilölle', function () {

        model.lisaaNumero(nimi_1, numero_11);

        expect(model.annaNumerot(nimi_2).length).toEqual(0);
    });


    it('lisää numeroita monelle henkilölle', function () {

        model.lisaaNumero(nimi_1, numero_11);
        model.lisaaNumero(nimi_1, numero_12);
        model.lisaaNumero(nimi_2, numero_21);

        expect(model.annaNumerot(nimi_1).length).toEqual(2);
        expect(model.annaNumerot(nimi_1)).toContain(numero_11);
        expect(model.annaNumerot(nimi_1)).toContain(numero_12);

        expect(model.annaNumerot(nimi_2).length).toEqual(1);
        expect(model.annaNumerot(nimi_2)).toContain(numero_21);
    });

    /*
     * Numeroiden poisto
     * ----------------------------------------------
     */

    it('ei poista numeroa, jos poiston hakuehto (nimi) ei toteudu', function () {

        model.lisaaNumero(nimi_1, numero_11);
        model.lisaaNumero(nimi_1, numero_12);

        model.poistaNumero(nimi_eioo, numero_12);

        expect(model.annaNumerot(nimi_1).length).toEqual(2);
        expect(model.annaNumerot(nimi_1)).toContain(numero_12);
    });

    it('ei poista numeroa, jos poiston hakuehto (numero) ei toteudu', function () {

        model.lisaaNumero(nimi_1, numero_11);
        model.lisaaNumero(nimi_1, numero_12);

        model.poistaNumero(nimi_1, numero_eioo);

        expect(model.annaNumerot(nimi_1).length).toEqual(2);
        expect(model.annaNumerot(nimi_1)).toContain(numero_11);
        expect(model.annaNumerot(nimi_1)).toContain(numero_12);
    });

    it('poistaa numeron toteutuvilla hakuehdoilla', function () {

        model.lisaaNumero(nimi_1, numero_11);
        model.lisaaNumero(nimi_1, numero_12);
        model.poistaNumero(nimi_1, numero_12);

        expect(model.annaNumerot(nimi_1).length).toEqual(1);
        expect(model.annaNumerot(nimi_1)).toContain(numero_11);
        expect(model.annaNumerot(nimi_1)).not.toContain(numero_12);
    });

    it('poistaa viimeisenkin numeron muistiosta', function () {

        model.lisaaNumero(nimi_1, numero_11);
        model.lisaaNumero(nimi_1, numero_12);
        model.poistaNumero(nimi_1, numero_12);
        model.poistaNumero(nimi_1, numero_11);

        expect(model.annaNumerot(nimi_1).length).toEqual(0);
    });

    it('palauttaa luettelon, jonka kautta ei voi lisätä numeroa muistioon', function () {

        model.lisaaNumero(nimi_1, numero_11);
        model.annaNumerot(nimi_1).push(numero_12);

        expect(model.annaNumerot(nimi_1).length).toEqual(1);
        expect(model.annaNumerot(nimi_1)).not.toContain(numero_12);
    });

});



