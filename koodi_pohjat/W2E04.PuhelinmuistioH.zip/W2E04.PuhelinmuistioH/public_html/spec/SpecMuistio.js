
/* global expect, muistio */

describe('Toiminta käyttöliittymän kautta:', function () {

    beforeEach(function () {

        setFixtures('\
        <div id="lomake"> \
            <label>Nimi: <input id="nimi"/></label>\
            <br/>\
            <label>Puhelinnumero: <input id="numero"/></label>\
            <br/>\
            <button id="etsi">Etsi</button>\
            <button id="lisaa">Lisää</button>\
        </div>\
              \
        <div id="luettelo">\
            <h2>Henkilön <span></span> numerot</h2>\
            <ul id="numerot"></ul>\
        </div>');

        muistio.init();
    });

    /*
     * Testidata
     * ----------------------------------------------
     */

    var nimi_1 = 'mikke';
    var numero_11 = '044-33669933';
    var numero_12 = '231';

    var nimi_2 = 'matti';
    var numero_21 = '1111';

    var nimi_eioo = 'jaakko';
    var numero_eioo = '333';

    /*
     * Numeroiden lisäys
     * ----------------------------------------------
     */

    it('lisää numeron henkilölle', function () {

        $('#nimi').val(nimi_1);
        $('#numero').val(numero_11);
        $('#lisaa').click();

        expect($('#luettelo h2 span').text()).toEqual(nimi_1);
        expect($('#numerot li').length).toEqual(1);
        expect($('#numerot li').text().substr(0, numero_11.length)).toEqual(numero_11);
    });

    it('ei lisää samaa numeroa kahteen kertaan', function () {

        $('#nimi').val(nimi_1);
        $('#numero').val(numero_11);
        $('#lisaa').click();
        $('#lisaa').click();

        expect($('#luettelo h2 span').text()).toEqual(nimi_1);
        expect($('#numerot li').length).toEqual(1);
        expect($('#numerot li').text().substr(0, numero_11.length)).toEqual(numero_11);
    });

    it('lisää henkilölle useita numeroita', function () {

        $('#nimi').val(nimi_1);
        $('#numero').val(numero_11);
        $('#lisaa').click();

        $('#numero').val(numero_12);
        $('#lisaa').click();

        expect($('#numerot li').length).toEqual(2);
        expect($('#numerot li').first().text().substr(0, numero_11.length)).toEqual(numero_11);
        expect($('#numerot li').last().text().substr(0, numero_12.length)).toEqual(numero_12);
    });

    it('ei lisää henkilön numeroa toiselle henkilölle', function () {

        $('#nimi').val(nimi_1);
        $('#numero').val(numero_11);
        $('#lisaa').click();

        $('#nimi').val(nimi_2);
        $('#etsi').click();

        expect($('#numerot li').length).toEqual(0);
    });

    it('lisää numeroita monelle henkilölle', function () {

        $('#nimi').val(nimi_1);
        $('#numero').val(numero_11);
        $('#lisaa').click();

        $('#nimi').val(nimi_1);
        $('#numero').val(numero_12);
        $('#lisaa').click();

        $('#nimi').val(nimi_2);
        $('#numero').val(numero_21);
        $('#lisaa').click();

        $('#nimi').val(nimi_1);
        $('#etsi').click();

        expect($('#numerot li').length).toEqual(2);
        expect($('#numerot li').first().text().substr(0, numero_11.length)).toEqual(numero_11);
        expect($('#numerot li').last().text().substr(0, numero_12.length)).toEqual(numero_12);

        $('#nimi').val(nimi_2);
        $('#etsi').click();

        expect($('#numerot li').length).toEqual(1);
        expect($('#numerot li').text().substr(0, numero_21.length)).toEqual(numero_21);
    });

    /*
     * Numeroiden poisto
     * ----------------------------------------------
     */


    it('poistaa henkilön numerot', function () {

        // lisätään henkilölle numero
        $('#nimi').val(nimi_1);
        $('#numero').val(numero_11);
        $('#lisaa').click();

        // lisätään henkilölle toinen numero
        $('#nimi').val(nimi_1);
        $('#numero').val(numero_12);
        $('#lisaa').click();

        // käyttöliittymässä on kaksi numeroa
        expect($('#numerot li').length).toEqual(2);

        // poistetaan ensimmäinen numeto
        $('#numerot li:first-child button').click();
        
        // toinen numero jää käyttöliittymään
        expect($('#numerot li').length).toEqual(1);
        expect($('#numerot li').text().substr(0, numero_12.length)).toEqual(numero_12);

        // poistetaan toinenkin numero
        $('#numerot li:first-child button').click();

        // käyttöliittymässä ei ole numeroita
        expect($('#numerot li').length).toEqual(0);

        // haetaan henkilön numerot
        $('#nimi').val(nimi_1);
        $('#etsi').click();

        // käyttöliittymässä ei ole numeroita
        expect($('#numerot li').length).toEqual(0);

    });

    it('ei poista toisen henkilön numeroita', function () {

        // lisätään henkilölle 1 numero
        $('#nimi').val(nimi_1);
        $('#numero').val(numero_11);
        $('#lisaa').click();

        // lisätään henkilölle 2 numero
        $('#nimi').val(nimi_2);
        $('#numero').val(numero_11);
        $('#lisaa').click();
        
        // haetaan henkilön 1 numerot
        $('#nimi').val(nimi_1);
        $('#etsi').click();

        //  poistetaan henkilön 1 numero
        $('#numerot li:first-child button').click();

        // numero ei ole käyttöliittymässä
        expect($('#numerot li').length).toEqual(0);

        // haetaan henkilön 2 numerot
        $('#nimi').val(nimi_2);
        $('#etsi').click();

        // numero ei ole käyttöliittymässä
        expect($('#numerot li').length).toEqual(1);

    });

});