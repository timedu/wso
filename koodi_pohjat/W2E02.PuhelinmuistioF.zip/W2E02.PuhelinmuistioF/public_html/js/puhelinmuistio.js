
/* global Function */

"use strict";

var muistio = muistio || {};

/*
 * +------------------------------------+
 * | MODEL                              |
 * +------------------------------------+
 * | - view                             |                      
 * | - henkilot = {}                    |                      
 * +------------------------------------+
 * | + annaNumerot(nimi)                |
 * | + lisaaNumero(nimi, numero)        |
 * | + poistaNumero(nimi, numero)       |
 * +------------------------------------+
 */

muistio.Model = function (view) {



};

/*
 * +------------------------------------+
 * | VIEW                               |
 * +------------------------------------+
 * | - spanNimi                         |
 * | - ulNumerot                        |
 * | - functionPoistaNumero             |
 * +------------------------------------+
 * | + asetaSpanNimi(elementti)         |
 * | + asetaUlNumerot(elementti)        |
 * | + asetaPoistonKasittelija(funktio) |
 * | + paivita(nimi, numerot)           |
 * | - esitaNumero(nimi, numero)        |
 * | - poistaNumero(event)              |
 * +------------------------------------+
 */

muistio.View = function () {




};


