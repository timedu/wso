
/* global expect, muistio, spyOn */

describe('Sovelletut tekniikat (initController):', function () {

    var model = null, view = null;

    beforeEach(function () {

        setFixtures('\
        <div id="lomake"> \
            <label>Nimi: <input id="nimi"/></label>\
            <br/>\
            <label>Puhelinnumero: <input id="numero"/></label>\
            <br/>\
            <button id="etsi">Etsi</button>\
            <button id="lisaa">Lisää</button>\
        </div>\
              \
        <div id="luettelo"></div>');

        model = new muistio.Model();
        view = new muistio.View();
    });


    it('käyttää konrollerin alustuksessa jQuery:n click-funktiota', function () {

        spyOn($.fn, "click");        
        muistio.initController(model, view);
        expect($.fn.click).toHaveBeenCalled();        
    });


    it('käyttää etsi-napin käsittelijässä jQuery:n val-funktiota', function () {

        muistio.initController(model, view);
        
        spyOn($.fn, "val").and.callThrough();               
        $('#etsi').click();        
        expect($.fn.val).toHaveBeenCalled();        
    });


    it('käyttää lisaa-napin käsittelijässä jQuery:n val-funktiota', function () {

        muistio.initController(model, view);

        spyOn($.fn, "val").and.callThrough();               
        $('#lisaa').click();        
        expect($.fn.val).toHaveBeenCalled();        
    });

    it('käyttää poista-napin käsittelijässä jQuery:n data-funktiota', function () {

        muistio.initController(model, view);
        muistio.initView(model, view);

        $('#nimi').val('nimi');
        $('#numero').val('numero');
        $('#lisaa').click();

        spyOn($.fn, "data").and.callThrough();           
        $('#luettelo li:first-child button').click();
        expect($.fn.data).toHaveBeenCalled();        
    });

});