
/* global muistio, expect, Function */


describe('Puhelinmuistio - View:', function () {

    var view;

    var HTML_ID = "kohde_elementti_kayttoliittymalle";
    var CSS_ID = '#' + HTML_ID;

    beforeEach(function () {
        setFixtures('<div id="' + HTML_ID + '"></div>');
        view = new muistio.View();
        view.asetaTemplate(muistio.template);
    });


    it('ei kaadu, jos paikkaa hahmonnettavalle käyttöliittymälle ei ole asetettu', function () {

        expect(function () {

            view.hahmonna('ned', [1, 2]);

        }).not.toThrow();

    });

    it('ei kaadu, jos paikkaa hahmonnettavalle käyttöliittymälle ei löydy', function () {

        expect(function () {

            view.asetaPaikka('ei_oo');
            view.hahmonna('ned', [1, 2]);

        }).not.toThrow();

    });

    it('rakentaa käyttöliittymään h2-otsikon, joka sisältää henkilön nimen', function () {

        var henkilonNimi = 'Ned Flanders';

        view.asetaPaikka(CSS_ID);
        view.hahmonna(henkilonNimi, []);

        expect($(CSS_ID + '>h2').length).toEqual(1);
        expect($(CSS_ID + '>h2').text()).toContain(henkilonNimi);
    });


    it('rakentaa käyttöliittymään henkilön puhelinnumerot sisältävän ul-listan', function () {

        var henkilonNimi = 'Ned Flanders';
        var numerot = ['111+222', 'numero-2'];

        view.asetaPaikka(CSS_ID);
        view.hahmonna(henkilonNimi, numerot);

        expect($(CSS_ID + '>ul').length).toEqual(1);
        expect($(CSS_ID + '>ul>li').length).toEqual(2);
        expect($(CSS_ID + '>ul').text()).toContain(numerot[0]);
        expect($(CSS_ID + '>ul').text()).toContain(numerot[1]);
    });

    it('ei rakenna käyttöliittymään li-elementtejä, jos henkilöllä ei ole puhelinnumeroita', function () {

        var henkilonNimi = 'Ned Flanders';
        var numerot = [];

        view.asetaPaikka(CSS_ID);
        view.hahmonna(henkilonNimi, numerot);

        expect($(CSS_ID + ' li').length).toEqual(0);
    });

    it('rakentaa käyttöliittymään puhelinnumeroille "X"-otsikoidut poisto-napit (button)', function () {

        var henkilonNimi = 'Ned Flanders';
        var numerot = ['111+222', 'numero-2'];

        view.asetaPaikka(CSS_ID);
        view.hahmonna(henkilonNimi, numerot);

        expect($(CSS_ID + '>ul').length).toEqual(1);
        expect($(CSS_ID + '>ul>li>button').length).toEqual(2);
        expect($(CSS_ID + '>ul>li:first-child>button').text()).toEqual("X");
    });


    it('asettaa poisto-napeille click-tapahtuman käsittelijän', function () {

        var henkilonNimi = 'Ned Flanders';
        var numerot = ['111+222', 'numero-2'];

        var spy = {poista: function () {}};
        spyOn(spy, 'poista');

        view.asetaPaikka(CSS_ID);
        view.asetaPoista(spy.poista);
        view.hahmonna(henkilonNimi, numerot);

        expect(function () {
            $(CSS_ID + '>ul>li>button').click();
        }).not.toThrow();

        expect(spy.poista).toHaveBeenCalledTimes(2);
    });


    it('ei kaadu, vaikka poisto-funktiota ei ole määritelty', function () {

        var henkilonNimi = 'Ned Flanders';
        var numerot = ['111+222', 'numero-2'];

        view.asetaPaikka(CSS_ID);

        view.hahmonna(henkilonNimi, numerot);

        expect(function () {

            $(CSS_ID + '>ul>li:first-child>button').click();

        }).not.toThrow();

    });


    it('ei kaadu, vaikka poisto-funktio ei ole oikeaa tyyppiä (function)', function () {

        var henkilonNimi = 'Ned Flanders';
        var numerot = ['111+222', 'numero-2'];

        view.asetaPaikka(CSS_ID);
        view.asetaPoista('tekstiä...');

        view.hahmonna(henkilonNimi, numerot);

        expect(function () {

            $(CSS_ID + '>ul>li:first-child>button').click();

        }).not.toThrow();

    });

});
