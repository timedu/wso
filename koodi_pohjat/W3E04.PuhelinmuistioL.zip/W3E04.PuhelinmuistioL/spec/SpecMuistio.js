
/* global expect, muistio */

describe('Toiminta käyttöliittymän kautta:', function () {

    var TIMEOUT = 50;

    beforeEach(function (done) {

        setFixtures('\
        <div id="lomake"> \
            <label>Nimi: <input id="nimi"/></label>\
            <br/>\
            <label>Puhelinnumero: <input id="numero"/></label>\
            <br/>\
            <button id="etsi">Etsi</button>\
            <button id="lisaa">Lisää</button>\
        </div>\
              \
        <div id="luettelo"></div>');

        var model = new muistio.Model();
        var view = new muistio.View();

        muistio.initModel(model, view);
        muistio.initView(model, view);
        muistio.initController(model, view);

        $.get('./php/muistio.php', 'reset=reset', function () {
            done();
        });
    });

    /*
     * Testidata
     * ----------------------------------------------
     */

    var nimi_1 = 'Homer';
    var numero_11 = '044-33669933';
    var numero_12 = '231';

    var nimi_2 = 'Bart';
    var numero_21 = '1111';

    var nimi_eioo = 'Ned';
    var numero_eioo = '333';



    describe('Numeroiden lisäys:', function () {

        it('esittää lisäyksen jälkeen henkilön nimen ja numeron sivulla', function (done) {

            $('#nimi').val(nimi_1);
            $('#numero').val(numero_11);
            $('#lisaa').click();

            setTimeout(function () {

                expect($('#luettelo h2').text()).toContain(nimi_1);
                expect($('#luettelo li').length).toEqual(1);
                expect($('#luettelo li').text().substr(0, numero_11.length)).toEqual(numero_11);

                done();

            }, TIMEOUT);

        });

        it('ei esitä henkilölle samoja numeroita', function (done) {

            $('#nimi').val(nimi_1);
            $('#numero').val(numero_11);
            $('#lisaa').click();
            $('#lisaa').click();

            setTimeout(function () {

                expect($('#luettelo h2').text()).toContain(nimi_1);
                expect($('#luettelo li').length).toEqual(1);
                expect($('#luettelo li').text().substr(0, numero_11.length)).toEqual(numero_11);

                done();

            }, TIMEOUT);

        });

        it('esittää lisäysten jälkeen henkilöllä useita eri numeroita', function (done) {

            $('#nimi').val(nimi_1);
            $('#numero').val(numero_11);
            $('#lisaa').click();

            $('#numero').val(numero_12);
            $('#lisaa').click();

            setTimeout(function () {

                expect($('#luettelo li').length).toEqual(2);
                expect($('#luettelo li').first().text().substr(0, numero_11.length)).toEqual(numero_11);
                expect($('#luettelo li').last().text().substr(0, numero_12.length)).toEqual(numero_12);

                done();

            }, TIMEOUT);

        });

        it('ei esitä henkilöllä toiselle henkilölle lisättyä numeroa', function (done) {

            $('#nimi').val(nimi_1);
            $('#numero').val(numero_11);
            $('#lisaa').click();

            setTimeout(function () {

                $('#nimi').val(nimi_2);
                $('#etsi').click();

                setTimeout(function () {

                    expect($('#luettelo li').length).toEqual(0);

                    done();

                }, TIMEOUT);
            }, TIMEOUT);

        });


        it('esitää useille henkilöille lisättyjä numeroita', function (done) {

            // numeroita henkilölle 1

            $('#nimi').val(nimi_1);
            $('#numero').val(numero_11);
            $('#lisaa').click();

            $('#nimi').val(nimi_1);
            $('#numero').val(numero_12);
            $('#lisaa').click();

            // numeroita henkilölle 2

            $('#nimi').val(nimi_2);
            $('#numero').val(numero_21);
            $('#lisaa').click();

            setTimeout(function () {

                // henkilön 1 numerot esille

                $('#nimi').val(nimi_1);
                $('#etsi').click();

                setTimeout(function () {

                    expect($('#luettelo li').length).toEqual(2);
                    expect($('#luettelo li').first().text().substr(0, numero_11.length)).toEqual(numero_11);
                    expect($('#luettelo li').last().text().substr(0, numero_12.length)).toEqual(numero_12);

                    // henkilön 2 numerot esille

                    $('#nimi').val(nimi_2);
                    $('#etsi').click();

                    setTimeout(function () {

                        expect($('#luettelo li').length).toEqual(1);
                        expect($('#luettelo li').text().substr(0, numero_21.length)).toEqual(numero_21);

                        done();

                    }, TIMEOUT);
                }, TIMEOUT);
            }, TIMEOUT);

        });

    });

    describe('Numeroiden poisto:', function () {

        it('ei esitä henkilöltä poistettuja numeroita', function (done) {

            // lisätään henkilölle numero

            $('#nimi').val(nimi_1);
            $('#numero').val(numero_11);
            $('#lisaa').click();

            // lisätään henkilölle toinen numero

            $('#nimi').val(nimi_1);
            $('#numero').val(numero_12);
            $('#lisaa').click();

            setTimeout(function () {

                // käyttöliittymässä on kaksi numeroa

                expect($('#luettelo li').length).toEqual(2);

                // poistetaan ensimmäinen numeto

                $('#luettelo li:first-child button').click();

                setTimeout(function () {

                    // toinen numero jää käyttöliittymään

                    expect($('#luettelo li').length).toEqual(1);
                    expect($('#luettelo li').text().substr(0, numero_12.length)).toEqual(numero_12);

                    // poistetaan toinenkin numero

                    $('#luettelo li:first-child button').click();

                    setTimeout(function () {

                        // käyttöliittymässä ei ole numeroita

                        expect($('#luettelo li').length).toEqual(0);

                        // haetaan henkilön numerot

                        $('#nimi').val(nimi_1);
                        $('#etsi').click();

                        setTimeout(function () {

                            // käyttöliittymässä ei ole numeroita

                            expect($('#luettelo li').length).toEqual(0);

                            done();

                        }, TIMEOUT);
                    }, TIMEOUT);
                }, TIMEOUT);
            }, TIMEOUT);

        });

        it('esittää henkilölle lisätyn numeron, \
vaikka se on poistettu toiselta henkilöltä', function (done) {

            // lisätään henkilölle 1 numero

            $('#nimi').val(nimi_1);
            $('#numero').val(numero_11);
            $('#lisaa').click();

            // lisätään henkilölle 2 numero

            $('#nimi').val(nimi_2);
            $('#numero').val(numero_11);
            $('#lisaa').click();

            setTimeout(function () {

                // haetaan henkilön 1 numerot

                $('#nimi').val(nimi_1);
                $('#etsi').click();

                setTimeout(function () {

                    //  poistetaan henkilön 1 numero

                    $('#luettelo li:first-child button').click();

                    setTimeout(function () {

                        // numero ei ole käyttöliittymässä

                        expect($('#luettelo li').length).toEqual(0);

                        // haetaan henkilön 2 numerot

                        $('#nimi').val(nimi_2);
                        $('#etsi').click();

                        setTimeout(function () {

                            // numero on käyttöliittymässä

                            expect($('#luettelo li').length).toEqual(1);
                            
                            done();

                        }, TIMEOUT);
                    }, TIMEOUT);
                }, TIMEOUT);
            }, TIMEOUT);

        });

    });


});