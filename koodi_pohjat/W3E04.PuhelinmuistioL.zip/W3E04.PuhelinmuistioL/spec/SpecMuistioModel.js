

/* global muistio, expect, Function */

describe('Puhelinmuistio - Model:', function () {

    // Testidata

    var nimi_1 = 'homer';
    var numero_11 = '044-33669933';
    var numero_12 = '231';

    var nimi_2 = 'bart';
    var numero_21 = '1111';

    var nimi_eioo = 'ned';
    var numero_eioo = '333';

    // ------------------------------------------------------------

    describe('Numeroiden lisäys:', function () {

        var model = null;

        beforeAll(function (done) {

            model = new muistio.Model();
            $.get('./php/muistio.php', 'reset=reset', function () {
                done();
            });

        });

        afterAll(function (done) {

            $.get('./php/muistio.php', 'reset=reset', function () {
                done();
            });

        });

        it('kutsuu lisaa-kuuntelijaa odotetulla parametrilla \n\
lisaaNumero-metodin suorituksen seurauksena ', function (done) {

            model.asetaKuuntelija('lisaa', function (s, a) {
                expect(s).toEqual(nimi_1);
                expect(a).toBeUndefined();
                done();
            });
            model.lisaaNumero(nimi_1, numero_11);
        });

        it('kutsuu anna-kuuntelijaa odotetulla parametrilla\n\
annaNumerot-metodin suorituksen seurauksena', function (done) {

            model.asetaKuuntelija('anna', function (s, a) {
                expect(s).toEqual(nimi_1);
                expect(a.length).toEqual(1);
                expect(a).toContain(numero_11);
                done();
            });
            model.annaNumerot(nimi_1);
        });

        it(': yrittää lisätä henkilölle hänellä jo olevaa numeroa', function (done) {

            model.asetaKuuntelija('lisaa', function () {
                done();
            });
            model.lisaaNumero(nimi_1, numero_11);
        });

        it('ei lisää samaa numeroa henkilölle kahdesti', function (done) {

            model.asetaKuuntelija('anna', function (s, a) {
                expect(s).toEqual(nimi_1);
                expect(a.length).toEqual(1);
                expect(a).toContain(numero_11);
                done();
            });
            model.annaNumerot(nimi_1);
        });

        it(': yrittää lisätä henkilölle toisen numeron', function (done) {

            model.asetaKuuntelija('lisaa', function () {
                done();
            });
            model.lisaaNumero(nimi_1, numero_12);
        });

        it('lisää henkilölle on kaksi numeroa', function (done) {

            model.asetaKuuntelija('anna', function (s, a) {
                expect(s).toEqual(nimi_1);
                expect(a.length).toEqual(2);
                expect(a).toContain(numero_11);
                expect(a).toContain(numero_12);
                done();
            });
            model.annaNumerot(nimi_1);
        });

        it('ei lisää henkilölle lisättyjä numeroita toiselle henkilölle', function (done) {

            model.asetaKuuntelija('anna', function (s, a) {
                expect(s).toEqual(nimi_2);
                expect(a.length).toEqual(0);
                done();
            });
            model.annaNumerot(nimi_2);
        });

        it(': yritttää lisätä toiselle henkilölle numeron', function (done) {

            model.asetaKuuntelija('lisaa', function () {
                done();
            });
            model.lisaaNumero(nimi_2, numero_21);
        });

        it('lisää toiselle henkilölle numeron', function (done) {

            model.asetaKuuntelija('anna', function (s, a) {
                expect(s).toEqual(nimi_2);
                expect(a.length).toEqual(1);
                expect(a).toContain(numero_21);
                done();
            });
            model.annaNumerot(nimi_2);
        });

        it('lisää numeron niin, että ensimmäisellä henkilöllä on edelleen samat kaksi numeroa', function (done) {

            model.asetaKuuntelija('anna', function (s, a) {
                expect(s).toEqual(nimi_1);
                expect(a.length).toEqual(2);
                expect(a).toContain(numero_11);
                expect(a).toContain(numero_12);
                done();
            });
            model.annaNumerot(nimi_1);
        });

    });

    // ------------------------------------------------------------

    describe('Numeroiden poisto:', function () {

        var model = null;

        beforeAll(function (done) {

            model = new muistio.Model();
            $.get('./php/muistio.php', 'reset=reset', function () {
                done();
            });

        });

        afterAll(function (done) {

            $.get('./php/muistio.php', 'reset=reset', function () {
                done();
            });

        });

        it(': lisää henkilölle numeron', function (done) {

            model.asetaKuuntelija('lisaa', function () {
                done();
            });
            model.lisaaNumero(nimi_1, numero_11);
        });

        it(': lisää henkilölle toisen numeron', function (done) {

            model.asetaKuuntelija('lisaa', function () {
                done();
            });
            model.lisaaNumero(nimi_1, numero_12);
        });

        it('kutsuu poista-kuuntelijaa odotetulla parametrilla \n\
poistaNumero-metodin suorituksen seurauksena ', function (done) {

            model.asetaKuuntelija('poista', function (s, a) {
                expect(s).toEqual(nimi_2);
                expect(a).toBeUndefined();
                done();
            });
            model.poistaNumero(nimi_2, numero_11);
        });

        it('ei poista henkilöltä numeroa, jos nimi-hakuehto ei täsmää', function (done) {

            model.asetaKuuntelija('anna', function (s, a) {
                expect(s).toEqual(nimi_1);
                expect(a.length).toEqual(2);
                expect(a).toContain(numero_11);
                expect(a).toContain(numero_12);
                done();
            });
            model.annaNumerot(nimi_1);
        });

        it(': yritää poistaa numeroa', function (done) {

            model.asetaKuuntelija('poista', function (s, a) {
                done();
            });
            model.poistaNumero(nimi_1, numero_eioo);
        });

        it('ei poista henkilöltä numeroa, jos numero-hakuehto ei täsmää', function (done) {

            model.asetaKuuntelija('anna', function (s, a) {
                expect(s).toEqual(nimi_1);
                expect(a.length).toEqual(2);
                expect(a).toContain(numero_11);
                expect(a).toContain(numero_12);
                done();
            });
            model.annaNumerot(nimi_1);
        });

        it(': yritää poistaa numeroa', function (done) {

            model.asetaKuuntelija('poista', function () {
                done();
            });
            model.poistaNumero(nimi_1, numero_11);
        });

        it('poistaa numeron henkilöltä', function (done) {

            model.asetaKuuntelija('anna', function (s, a) {
                expect(s).toEqual(nimi_1);
                expect(a.length).toEqual(1);
                expect(a).toContain(numero_12);
                done();
            });
            model.annaNumerot(nimi_1);
        });

        it(': yritää poistaa numeroa', function (done) {

            model.asetaKuuntelija('poista', function () {
                done();
            });
            model.poistaNumero(nimi_1, numero_12);
        });

        it('poistaa viimeisenkinnumeron henkilöltä', function (done) {

            model.asetaKuuntelija('anna', function (s, a) {
                expect(s).toEqual(nimi_1);
                expect(a.length).toEqual(0);
                done();
            });
            model.annaNumerot(nimi_1);
        });

    });


});



