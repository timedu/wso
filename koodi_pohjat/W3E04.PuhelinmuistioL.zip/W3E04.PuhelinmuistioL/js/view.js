
/* global Mustache, Function */

"use strict";

var muistio = muistio || {};

/**
 * Alustaa näkymän
 * @param {muistio.Model} model
 * @param {muistio.View} view
 */
muistio.initView = function (model, view) {

    view.asetaPaikka('#luettelo');
    view.asetaTemplate(muistio.template);
};

/**
 * Muodostaa näkymä-olion
 * @returns {muistio.View}
 */
//muistio.View = function (p) {
muistio.View = function () {

    /*
     * sisäinen data ja setterit
     */

    var paikka = '';
    var template = '';
    var poista = function () {};

    this.asetaPaikka = function (s) {
        if (typeof s === 'string') {
            paikka = s;
        }
    };

    this.asetaTemplate = function (s) {
        if (typeof s === 'string') {
            template = s;
        }
    };

    this.asetaPoista = function (f) {
        if (f instanceof Function) {
            poista = f;
        }
    };

    /*
     * näkymän hahmonnus 
     */

    this.hahmonna = function (nimi, numerot) {

        // ...

    };
};


/**
 * Nämymän hahmontama template
 * @type String
 */
muistio.template = "...";
