
/*
 * Web-selainohjelmointi
 * Tehtävä 3.4 
 * 
 * Nimi: 
 * OpNro:
 */

/* global Function */

"use strict";

var muistio = muistio || {};

/**
 * Asettaa mallin kuuntelijat
 * @param {muistio.Model} model
 * @param {musitio.View} view
 */
muistio.initModel = function (model, view) {
    
    // ...
    
};

/**
 * Muodostaa malli-olion
 * @returns {muistio.Model}
 */
muistio.Model = function () {
    
    /* 
     * Tietojen talletukseen käytettävä web-palelu
     */

    var URL = './php/muistio.php';

    /* 
     * Kuuntelijat ja niiden asetus
     */

    var kuuntelijat = {
        'anna': function () {},
        'lisaa': function () {},
        'poista': function () {}
    };

    this.asetaKuuntelija = function (tapahtuma, funktio) {

        if (Object.keys(kuuntelijat).includes(tapahtuma) && funktio instanceof Function) {
            kuuntelijat[tapahtuma] = funktio;
        }
    };

    /* 
     * Mallin käyttöön liityvät metodit 
     */

    this.annaNumerot = function (nimi) {

        var xhr = new XMLHttpRequest();
        xhr.open('GET', URL + '?nimi=' + nimi);
        xhr.onload = function () {
            var numerot = JSON.parse(xhr.responseText);
            kuuntelijat.anna(nimi,numerot);
        };
        xhr.send();

    };

    this.lisaaNumero = function (nimi, numero) {

        var xhr = new XMLHttpRequest();

        xhr.open('POST', URL);
        xhr.setRequestHeader("Content-type", "application/json");

        xhr.onload = function () {
            kuuntelijat.lisaa(nimi);
        };

        xhr.send(JSON.stringify({
            nimi: nimi,
            numero: numero
        }));

    };

    this.poistaNumero = function (nimi, numero) {

        var xhr = new XMLHttpRequest();

        xhr.open('DELETE', URL);
        xhr.setRequestHeader("Content-type", "application/json");

        xhr.onload = function () {
            kuuntelijat.poista(nimi);
        };

        xhr.send(JSON.stringify({
            nimi: nimi,
            numero: numero
        }));

    };

};


