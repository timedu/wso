
"use strict";

var muistio = muistio || {};

$(function () {

    var model = new muistio.Model();   
    var view = new muistio.View();

    muistio.initModel(model, view);
    muistio.initView(model, view);
    muistio.initController(model, view);  
});

