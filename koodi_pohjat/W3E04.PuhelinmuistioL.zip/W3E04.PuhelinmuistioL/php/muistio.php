<?php

#
# Tehtävä 3.3 / puhelinmuistio-datan ylläpito palvelimella (istunnossa)
#

define('HTTP_ORIGIN', filter_input(INPUT_SERVER, 'HTTP_ORIGIN'));
define('MAX_STR_LENGHT', 20);
define('MAX_ARR_LENGTH', 10);

header('Access-Control-Allow-Origin: ' . HTTP_ORIGIN);
header('Access-Control-Allow-Headers: Content-Type');
header('Access-Control-Allow-Credentials: true');
header('Access-Control-Allow-Methods: GET, POST, DELETE, OPTIONS');

header('Content-Type: application/json');

/*
 * ==================================================================== *
 * Istunto ja siinä ylläpidettävä pehelinmuistion data                  *
 * -------------------------------------------------------------------- *
 */

session_start();

if (!isset($_SESSION['henkilot'])):

    $_SESSION['henkilot'] = [];

endif;

/*
 * ==================================================================== *
 * Pyynnön käsittely                                                    *
 * -------------------------------------------------------------------- *
 */

switch (filter_input(INPUT_SERVER, 'REQUEST_METHOD')):

    case 'GET':

        $reply = doGet([
            'dump' => filter_input(INPUT_GET, 'dump'),
            'reset' => filter_input(INPUT_GET, 'reset'),
            'nimi' => filter_input(INPUT_GET, 'nimi'),
            'henkilot' => &$_SESSION['henkilot']
        ]);
        break;

    case 'POST':

        $reply = doPost([
            'data' => json_decode(file_get_contents('php://input'), TRUE),
            'henkilot' => &$_SESSION['henkilot']
        ]);
        break;

    case 'DELETE':

        $reply = doDelete([
            'data' => json_decode(file_get_contents('php://input'), TRUE),
            'henkilot' => &$_SESSION['henkilot']
        ]);
        break;

endswitch;

echo json_encode($reply);

/*
 * ==================================================================== *
 * Pyynnön metodikohtaiset käsittelijäfunktiot                          *
 * -------------------------------------------------------------------- *
 * doGet, doPost, doDelete                                              *
 * -------------------------------------------------------------------- *
 */

/**
 * Palauttaa puhelinmuistiosta henkilön numerotaulukon. Jos pyynnössä 
 * on dump-parametri, funktio palautaa koko puhelinmuistion sisällön. 
 * Jos pyynnössä on reset-parametri, funktio alustaa puhelinmuistion 
 * tyhjäksi. dump-parametri tulkitaan ensin.
 * 
 * @param Array $params kutsuparametrit: nimi, reset, henkilot
 * @return Array henkilon puhelinnumerotaulukko
 */
function doGet($params) {

    extract($params, EXTR_REFS); // dump, reset, nimi, henkilot

    if (isset($dump)):
        return $henkilot;
    endif;

    if (isset($reset)):
        return $henkilot = [];
    endif;

    $nimi = substr($nimi, 0, MAX_STR_LENGHT);
    return isset($henkilot[$nimi]) ? $henkilot[$nimi] : [];
}

/**
 * Lisää numeron henkilölle puhelinmuistioon. Puhelinmuistion koko
 * sekä nimien ja numeroiden pituus on rajoitettu.
 * 
 * @param Array $params kutsuparametrit: data (array), henkilot (Array)
 * @return Object palauteviesti
 */
function doPost($params) {

    extract($params, EXTR_REFS); // henkilot, data

    if (!prepareParams($data)):
        return 'Nimi tai numero puuttuu pyynnöstä.';
    endif;
    extract($data); // nimi, numero

    if (!isset($henkilot[$nimi])):

        if (count($henkilot) >= MAX_ARR_LENGTH):
            return 'Uusi henkilö ei mahdu muistioon.';
        endif;
        $henkilot[$nimi] = [];

    endif;

    if (in_array($numero, $henkilot[$nimi])):
        return 'Numero on jo henkilön numerotaulukossa.';
    endif;

    if (count($henkilot[$nimi]) >= MAX_ARR_LENGTH):
        return 'Uusi numero ei mahdu henkilön numerotaulukkoon.';
    endif;

    $henkilot[$nimi][] = $numero;
    return 'Uusi numero lisätty henkilön numerotaulukkoon.';
}

/**
 * Poistaa ...
 * 
 * @param Array $params
 */
function doDelete($params) {

    extract($params, EXTR_REFS); // data, henkilot

    if (!prepareParams($data)):
        return 'Nimi tai numero puuttuu pyynnöstä.';
    endif;

    extract($data); // nimi, numero

    if (!isset($henkilot[$nimi])):
        return 'Henkilöä ei ole puhelinmuistiossa.';
    endif;

    $index = array_search($numero, $henkilot[$nimi]);
    if ($index === FALSE):
        return 'Numeroa ei löydy henkilön numerotaulukosta.';
    endif;

    array_splice($henkilot[$nimi], $index, 1);

    if (count($henkilot[$nimi]) <= 0):

        unset($henkilot[$nimi]);
        return 'Numero ja henkilö poistettu puhelinmuistiosta.';

    endif;

    return 'Numero poistettu henkilön numerotaulukosta.';
}

/*
 * ==================================================================== *
 * Apufunktiot                                                          *
 * -------------------------------------------------------------------- *
 * debug, prepareParams                                                 *
 * -------------------------------------------------------------------- *
 */

/**
 * Tulostaa datan virhekanavaan (esim. NetBeansin output-ikkunaan).
 * 
 * @param mixed $data
 */
function debug($data) {
    file_put_contents('php://stderr', 'DEBUG: ' . print_r($data, true) . "\n");
}

/**
 * Tutkii, onko parametrit (nimi, numero) annettu. Typistää parametrit 
 * maksimimittaansa.
 * 
 * @param array $data Parametrit: nimi (string) ja numero (string)
 * @return boolean Onko molemmat parametrit annettu.
 */
function prepareParams(&$data) {

    if (!isset($data['nimi']) || !isset($data['numero'])):
        return FALSE;
    endif;

    $data['nimi'] = substr($data['nimi'], 0, MAX_STR_LENGHT);
    $data['numero'] = substr($data['numero'], 0, MAX_STR_LENGHT);

    return TRUE;
}
