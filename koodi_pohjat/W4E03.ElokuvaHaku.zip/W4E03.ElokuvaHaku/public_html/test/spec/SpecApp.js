
/* global expect */

var
        APP = 'MovieFilterApp',
        CONTROLLER = 'MovieFilterController',
        TEMPLATE = '../todo/template.html';

describe(APP, function () {

    var templateHtml;

    beforeAll(function () {
        templateHtml = $.ajax(TEMPLATE, {async: false}).responseText;
    });

    describe('template', function () {

        var template;

        beforeAll(function () {
            template = $(templateHtml);
        });

        it('sisältää ylätasolle elementit: fieldset, h2, ul', function () {

            var firstElement = template.find('*:first');
            var secondElement = firstElement.next();
            var thirdElement = secondElement.next();

            expect(firstElement.prop('tagName')).toBe('FIELDSET');
            expect(secondElement.prop('tagName')).toBe('H2');
            expect(thirdElement.prop('tagName')).toBe('UL');
        });


        it('sisältää odotetut määrät elementtejä: legend, label, input, \n\
li, strong', function () {

            expect(template.find('legend').length).toBe(1);
            expect(template.find('label').length).toBe(3);
            expect(template.find('input').length).toBe(3);
            expect(template.find('li').length).toBe(1);
            expect(template.find('strong').length).toBe(1);
        });

    });

    describe('view', function () {

        var scope, controller, cTemplate;

        beforeEach(function () {

            module(APP);

            inject(function ($compile, $rootScope, $controller) {

                scope = $rootScope.$new();
                cTemplate = $compile($(templateHtml))(scope);
                controller = $controller(CONTROLLER, {
                    $scope: scope
                });
            });

        });


        it('esittää alussa koko aineiston', function () {

            scope.$digest();

            var elokuvat = cTemplate.find('li');

            expect(elokuvat.length).toBe(10);
            expect(elokuvat.text()).toContain('Hayao Miyazaki');
            expect(elokuvat.find('strong').text()).toContain('The Matrix');
            expect(elokuvat.find('strong').text()).not.toContain('Hayao Miyazaki');
        });

        xdescribe('TARKASTA SOVELLUSTA AJAMALLA (ESIM.)', function () {

            it('esittää hakuehdolla "Nimi: ri" neljä elokuvaa', function () {
                expect(true).toBe(true);
            });

            it('esittää hakuehdolla "Nimi: ri, Ohjaaja: ki" kaksi elokuvaa', function () {
                expect(true).toBe(true);
            });

            it('esittää hakuehdolla "Nimi: ri, Julkaisuvuosi: 2001" kaksi elokuvaa', function () {
                expect(true).toBe(true);
            });

        });
    });
});

