

// ---------------------------------------
// Web-selainohjelmointi
// Tehtävä 4.5
// ---------------------------------------
var OPISKELIJA = {
    nimi: 'N.N.',
    numero: '999999'
};
// --------------------------------------- 


var CalcApp = angular.module('CalcApp', []);

CalcApp.controller('CalcController', function ($scope) {

    var LUKU = /^\s*[0-9]{1,}\s*$/;
    var NOLLA = /^\s*0{1,}\s*$/;

    $scope.luku1 = '0';
    $scope.luku2 = '0';

    // laskutoimitukset



    // painonappien aktiivisuuden kontrolli



});
