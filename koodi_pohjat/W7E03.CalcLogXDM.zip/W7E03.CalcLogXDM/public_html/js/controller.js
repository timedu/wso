
/* global CalcApp */

CalcApp.controller('CalcController', function ($scope, CalcService, LogService) {

    $scope.calculate = function (operaattori) {

        CalcService.calc({
            operandi_1: $scope.operandi_1,
            operandi_2: $scope.operandi_2,
            operaattori: operaattori
        }, function (laskutoimitus) {
             $scope.naytto = laskutoimitus;
             LogService.log(laskutoimitus);
        });
    };

});
