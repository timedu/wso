
// 
// Web-selainohjelmointi
// Tehtävä 7.3
// 
var OPISKELIJA = {
    nimi: 'N.N.',
    numero: '999999'
};
//  

/* global CalcApp, Window */

CalcApp.service('LogService', function (LOG_WINDOW) {

    this.log = function (data) {
        // ...
    };

});

