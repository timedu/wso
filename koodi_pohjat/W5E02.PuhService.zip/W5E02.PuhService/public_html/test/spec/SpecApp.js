
/* global expect */

var APP = 'PuhService';

describe(APP, function () {

    xdescribe('TARKASTA SOVELLUS SITÄ AJAMALLA', function () {

        it('testejä saatetaan julkaista myöhemmin', function () {
            expect(true).toBe(true);
        });

    });

});

