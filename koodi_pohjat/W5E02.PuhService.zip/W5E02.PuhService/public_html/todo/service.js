
// ---------------------------------------
// Web-selainohjelmointi
// Tehtävä 5.2
// ---------------------------------------
//var OPISKELIJA = {
//    nimi: 'N.N.',
//    numero: '999999'
//};
// --------------------------------------- 


/* global PuhApp */

PuhApp.service('Muistio', function () {

    // ...

});
