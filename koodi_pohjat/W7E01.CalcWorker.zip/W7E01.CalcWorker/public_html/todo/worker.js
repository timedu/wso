
// 
// Web-selainohjelmointi
// Tehtävä 7.1
// 
var OPISKELIJA = {
    nimi: 'N.N.',
    numero: '999999'
};
//  

/* global self */



