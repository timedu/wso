
/* global CalcApp */

CalcApp.controller('CalcController', function ($scope, CalcService) {

    $scope.calculate = function (operaattori) {

        CalcService.calc({
            operandi_1: $scope.operandi_1,
            operandi_2: $scope.operandi_2,
            operaattori: operaattori
        }, function (laskutoimitus) {
            
            // jos funktio suoritetaan angular-kontekstissa,
            // sen sisällöksi riittää tämä sijoituslause:
            
             $scope.naytto = laskutoimitus;
            
            // workerin yhteydessä kuitenkin ollaan kontekstin 
            // ulkopuolella, joten on käytettävä $apply-metodia:
            
//            $scope.$apply(function () {
//                $scope.naytto = laskutoimitus;
//            });
            
        });
    };

});
