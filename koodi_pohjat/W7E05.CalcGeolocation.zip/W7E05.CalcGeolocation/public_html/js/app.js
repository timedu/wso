
//
// angular-moduuli
// 

var CalcApp = angular.module('CalcApp', []);

CalcApp.constant('GEO_TIMEOUT', 10000);


//
// jqueryui -käyttöliittymän alustus
//

$(function () {

    var laskin = $('#laskin').dialog({
        dialogClass: 'no-close',
        title: 'Laskin',
        width: 'auto',
        resizable: false,
        show: 'puff',
        open: function () {
            $('input:first-child', laskin).focus();
        }
    });

    $('textarea, input', laskin)
            .addClass('ui-widget-content ui-corner-all');

    $('button', laskin).button();

    laskin.css('display', 'block');
});


