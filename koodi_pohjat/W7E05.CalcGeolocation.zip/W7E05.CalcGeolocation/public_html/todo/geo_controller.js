
// // 
// Web-selainohjelmointi
// Tehtävä 7.5
// 
//var OPISKELIJA = {
//    nimi: 'N.N.',
//    numero: '999999'
//};
//  



/* global CalcApp */

CalcApp.controller('GeoController', function ($scope, GeoService) {
    
    GeoService.getPosition(function (reply) {
        
        // ...

    });

});
