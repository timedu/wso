

/* global expect, Function, UusiPuhelinmuistio, Puhelinmuistio */

describe('Puhelinmuistion rakenne (Versio 2)', function () {

    it('sisältää UusiPuhelinmuistio -muodostinfunktion', function () {
        expect(UusiPuhelinmuistio instanceof Function).toBeTruthy();
    });

    it('muodostimen prototyyppi-attribuutilla ei ole ominaisuuksia', function () {                
        expect(Object.keys(UusiPuhelinmuistio.prototype).length).toEqual(0);
    });

    var muistio = UusiPuhelinmuistio();

    it('muistio-olio ei ole tyyppiä Puhelinmuistio', function () {
        expect(muistio instanceof Puhelinmuistio).toBeFalsy();
    });

    it('muistio-oliolla on lisaaNumero -metodi', function () {
        expect(muistio.hasOwnProperty('lisaaNumero') && muistio.lisaaNumero instanceof Function).toBeTruthy();
    });

    it('muistio-oliolla on annaNumerot -metodi', function () {
        expect(muistio.hasOwnProperty('annaNumerot') && muistio.annaNumerot instanceof Function).toBeTruthy();
    });

    it('muistio-oliolla on poistaNumero -metodi', function () {
        expect(muistio.hasOwnProperty('poistaNumero') && muistio.poistaNumero instanceof Function).toBeTruthy();
    });

    it('muistio-oliolla ei ole metodien lisäksi muita ominaisuuksia', function () {                
        expect(Object.keys(muistio).length).toEqual(3);
    });
    
});
