
"use strict";

/*
 * Tehtävä 1.3 Puhelinmuistio
 * 
 * Nimi: 
 * OpNro:
 */


function Puhelinmuistio() {
    
}


function UusiPuhelinmuistio() {
    
}

