"use strict";

window.addEventListener('load', function () {

    var parametrinSijainti = window.location.href.indexOf('?') + 1;    
    var parametri = window.location.href.substring(parametrinSijainti);

    switch (parametri) {
        
        case 'new':
            init(new Puhelinmuistio());
            break;
        
        case 'Uusi':
            init(UusiPuhelinmuistio());
            break;
            
        default:
            console.log('odottamaton url-parametri');        
    }

});

function init(muistio) {

    /*
     * -----------------------------------------------------------
     * Viitattavat käyttöliittymäelementit
     * -----------------------------------------------------------
     */

    var inputNimi = document.getElementById('nimi');
    var inputNumero = document.getElementById('numero');

    var buttonEtsi = document.getElementById('etsi');
    var buttonLisaa = document.getElementById('lisaa');

    var spanHenkilo = document.querySelector('#luettelo h2 span');
    var ulNumerot = document.getElementById('numerot');

    /*
     * -----------------------------------------------------------
     * Etsi- ja Lisää -nappien click-käsittelijöiden rekisteröinti
     * -----------------------------------------------------------
     */

    buttonEtsi.onclick = etsiNumerot;
    buttonLisaa.onclick = lisaaNumero;

    /*
     * -----------------------------------------------------------
     * Painonappien click-tapahtumien käsittelijät
     * -----------------------------------------------------------
     */

    function etsiNumerot() {
        esitaNumerot(inputNimi.value.trim());
    }

    function lisaaNumero() {
        muistio.lisaaNumero(inputNimi.value.trim(), inputNumero.value.trim());
        esitaNumerot(inputNimi.value.trim());
    }

    function poistaNumero(e) {

        var nimi = e.target.dataset.nimi.trim();
        var numero = e.target.dataset.numero.trim();

        muistio.poistaNumero(nimi, numero);
        esitaNumerot(nimi);
    }

    /*
     * -----------------------------------------------------------
     * Apufunktiot
     * -----------------------------------------------------------
     */

    function esitaNumerot(nimi) {

        spanHenkilo.textContent = nimi;

        ulNumerot.innerHTML = '';

        muistio.annaNumerot(nimi).forEach(function (numero) {

            var buttonPoista = document.createElement('button');
            buttonPoista.dataset.nimi = nimi;
            buttonPoista.dataset.numero = numero;
            buttonPoista.textContent = 'X';

            buttonPoista.onclick = poistaNumero;

            var liNumero = document.createElement('li');
            var textNumero = document.createTextNode(numero);
            liNumero.appendChild(textNumero);
            liNumero.appendChild(buttonPoista);

            ulNumerot.appendChild(liNumero);
        });
    }

}

