
/* global moment */

// ---------------------------------------
// Web-selainohjelmointi
// Tehtävä 4.4
// ---------------------------------------
var OPISKELIJA = {
    nimi: 'N.N.',
    numero: '999999'
};
// --------------------------------------- 

var ValidatorApp = angular.module('ValidatorApp', ['validation.match']);

ValidatorApp.directive('hetu', function () {
    return {
        require: 'ngModel',
        link: function (scope, elm, attrs, ctrl) {

            ctrl.$validators.hetu = function (modelValue, viewValue) {

                // ...

            };
        }
    };
});


//............0123456789012345678901234567890
var MERKIT = '0123456789ABCDEFHJKLMNPRSTUVWXY';

function isValidHetu(hetuko) {

    if (!hetuko.match(/^\d{6}-\d{3}\w$/)) {
        return false;
    }

    var pvm = hetuko.substr(0, 6);

    if (!moment(pvm, 'DDMMYY', true).isValid()) {
        return false;
    }

    var jarjestysLuku = hetuko.substr(7, 3);
    var tarkistusMerkki = hetuko.substr(10, 1);

    var jakoJaannos = Number.parseInt(pvm + jarjestysLuku) % 31;
    var odotettuTarkistusMerkki = MERKIT.charAt(jakoJaannos);

    if (tarkistusMerkki !== odotettuTarkistusMerkki) {
        return false;
    }

    return true;
}
