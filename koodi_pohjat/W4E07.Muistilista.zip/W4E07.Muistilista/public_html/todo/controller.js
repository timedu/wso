

// ---------------------------------------
// Web-selainohjelmointi
// Tehtävä 4.7
// ---------------------------------------
var OPISKELIJA = {
    nimi: 'N.N.',
    numero: '999999'
};
// --------------------------------------- 

/* global TODOS */

var TodoApp = angular.module('TodoApp', []);

TodoApp.controller('TodoController', function ($scope) {

    $scope.todos = TODOS.slice();
    $scope.newTask = '';

    // ...

});
