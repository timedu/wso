
/*
 * author: TiM
 */


/* global expect, spyOn, OPISKELIJA */

var APP = 'TodoApp';
var CONTROLLER = 'TodoController';
var TEMPLATE = '../todo/template.html';

/*
 * testiaineisto (alkaa)
 */
var TODOS = [
    {
        task: 'Opiskele Angularia',
        priority: 1,
        done: false
    },
    {
        task: 'Käy kaupassa',
        priority: 3,
        done: true
    },
    {
        task: 'Ruoki koira',
        priority: 2,
        done: true
    }
];
var SORTED_TODOS = TODOS.slice().sort(function (a, b) {
    return a.priority - b.priority;
});
var TODOS_DONE = (function () {
    var count = 0;
    TODOS.forEach(function (todo) {
        count += todo.done ? 1 : 0;
    });
    return count;
})();
var TODOS_REMAINING = TODOS.length - TODOS_DONE;
/*
 * testiaineisto (päättyy)
 */


describe(APP + ' / ' + OPISKELIJA.nimi, function () {

    var templateHtml;

    beforeAll(function () {
        templateHtml = $.ajax(TEMPLATE, {async: false}).responseText;
    });

    describe('template', function () {
        it('sisältää oletetut elementit', function () {
            var tpl = $(templateHtml);
            expect(tpl.find('div#todo-container').length).toBe(1);
            expect(tpl.find('div#add-todo-container').length).toBe(1);
            expect(tpl.find('div.todo').length).toBe(1);
            expect(tpl.find('div#todo-footer').length).toBe(1);
        });
    });

    describe('view', function () {

        var scope, controller, tpl;

        beforeEach(function () {

            module(APP);

            inject(function ($compile, $rootScope, $controller) {

                scope = $rootScope.$new();
                tpl = $compile($(templateHtml))(scope);
                controller = $controller(CONTROLLER, {
                    $scope: scope
                });
            });

        });

        it('esittää muistilistan tehtävät', function () {

            scope.$digest();

            expect(tpl.find('div.todo').length).toEqual(TODOS.length);

            TODOS.forEach(function (todo) {
                expect(tpl.find('div.todo').text()).toContain(todo.task);
            });
        });

        it('esittää tehtävät prioriteetin mukaisessa järjestyksessä', function () {

            scope.$digest();

            var todos = tpl.find('div.todo');

            for (i = 0; i < todos.length; i++) {
                expect(Number($(todos[i]).find('input:text').val())).toEqual(SORTED_TODOS[i].priority);
            }
        });

        it('esittää valmiit tehtävät tsekattuina ja yliviivattuina', function () {

            scope.$digest();

            var todos = tpl.find('div.todo');

            for (i = 0; i < todos.length; i++) {
                expect($(todos[i]).find('input:checkbox').is(':checked')).toBe(SORTED_TODOS[i].done);
                expect($(todos[i]).find('span').is('.todo-done')).toBe(SORTED_TODOS[i].done);
            }
        });

        it('esittää valmiiden ja keskeneräisten tehtävävien lukumäärän', function () {

            scope.$digest();

            expect(Number(tpl.find('#todos-done').text())).toEqual(TODOS_DONE);
            expect(Number(tpl.find('#todos-remaining').text())).toEqual(TODOS_REMAINING);
        });


        it('lisää uuden keskeneräisen tehtävän prioriteetilla 1', function () {

            scope.$digest();

            //console.log(tpl.find('#todo-footer').text());

            var uusi = Math.random().toString();

            tpl.find('#add-todo-container input:text').val(uusi).trigger('input');

            $(tpl.find('#add-todo-container button')[0]).trigger('click');

            scope.$digest();

            // tulostaa tyhjää ... (?):
            // console.log(scope.newTask);

            var newTask = tpl.find('.todo:contains("' + uusi + '")');

            expect(newTask.length).toEqual(1);
            expect(newTask.find('input:text').val()).toEqual('1');
            expect(newTask.find('input:checkbox').is(':checked')).toBeFalsy();
            expect(newTask.find('span').is('.done-task')).toBeFalsy();
        });

        it('siirtää uuden tehtävän viimeiseksi muutettaessa sen prioriteetin \n\
lukuarvoa tehtäväjoukon suurimmaksi', function () {

            scope.$digest();

            var uusi = Math.random().toString();

            tpl.find('#add-todo-container input:text').val(uusi).trigger('input');

            $(tpl.find('#add-todo-container button')[0]).trigger('click');

            scope.$digest();

            var newTask = tpl.find('.todo:contains("' + uusi + '")');

            newTask.find('input:text')
                    .val(SORTED_TODOS[SORTED_TODOS.length - 1].priority + 1)
                    .trigger('blur');

            scope.$digest();

            var todos = tpl.find('.todo');

            expect($(todos[todos.length - 1]).text()).toContain(uusi);

        });


        it('poistaa tehtävän klikattaessa ao. nappia', function () {

            scope.$digest();

            var firstTodo = $(tpl.find('.todo')[0]);
            firstTodo.find('button.remove-todo').trigger('click');

            expect(tpl.find('.todo').length).toEqual(SORTED_TODOS.length - 1);
            expect(tpl.find('.todo').text()).not.toContain(SORTED_TODOS[0].task);
        });


        it('merkitsee kaikki tehtävät tehdyksi klikattaessa ao. nappia', function () {

            scope.$digest();

            // tämän lauseen jälkeen konsolille tulostuu outoja arvoja ...
            // tpl.find('.todo input:checkbox').prop('checked', false);
            // ... vaihdettu seuraavaan, jolloin tulosteet odotettuja:

            tpl.find('.todo input:checkbox:checked').trigger('click');

            //console.log(tpl.find('input:checkbox:checked').length);
            //console.log(tpl.find('#todo-footer').text());

            tpl.find('button#mark-todos-done').trigger('click');

            //console.log(tpl.find('input:checkbox:checked').length);
            //console.log(tpl.find('#todo-footer').text());

            expect(tpl.find('input:checkbox:checked').length).toBe(SORTED_TODOS.length);
        });


        it('poistaa kaikki tehtävät klikattaessa ao. nappia, kun \n\
varmistuskysymykseen vastataan myönteisesti', function () {

            scope.$digest();

            // edellisen testin seurauksena kaikki tehtävät
            // on merkitty suoritetuksi ... miksi scope säilyy?

            //console.log(tpl.find('input:checkbox:checked').length);
            //console.log(tpl.find('#todo-footer').text());

            spyOn(window, 'confirm').and.returnValue(true);

            tpl.find('button#remove-todos').trigger('click');

            expect(window.confirm).toHaveBeenCalled();
            expect(tpl.find('.todo').length).toEqual(0);
        });

        it('ei poista tehtäviä klikattaessa ao. nappia, kun \n\
varmistuskysymykseen vastataan kielteisesti', function () {

            scope.$digest();

            spyOn(window, 'confirm').and.returnValue(false);

            tpl.find('button#remove-todos').trigger('click');

            expect(window.confirm).toHaveBeenCalled();
            expect(tpl.find('.todo').length).toEqual(SORTED_TODOS.length);
        });


        it('huomioi yksikön ja monikon valmiiden ja keskeneräisten tehtävien\n\
lukumäärien esityksessä', function () {

            scope.$digest();

            // kaikki tehtävät on merkitty tehdyksi;  
            // tilanne aiemman testin peruja (!?)
            //console.log(tpl.find('#todo-footer').text());

            // varmistetaan, että aineistossa on tarpeeksi tehtäviä
            expect(tpl.find('.todo').length).toBeGreaterThan(2);

            // ensimmäinen tehtavä tehdyksi muut ei
            tpl.find('.todo input:checkbox:checked').trigger('click');
            $(tpl.find('.todo input:checkbox')[0]).trigger('click');

            var footerText = tpl.find('#todo-footer')
                    .text() // poistetaan rivinvaihdot
                    .replace(/(\r\n|\n|\r)/gm,"");
            
            //console.log(footerText);
            expect(/\stehtävä\s.*\stehtävää\s/.test(footerText)).toBeTruthy();

        });

    });

});

