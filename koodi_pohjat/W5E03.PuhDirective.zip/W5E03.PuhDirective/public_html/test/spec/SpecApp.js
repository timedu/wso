
/* global expect */

var APP = 'PuhDirective';

describe(APP, function () {

    xdescribe('TARKASTA SOVELLUS SITÄ AJAMALLA', function () {

        it('testejä saatetaan julkaista myöhemmin', function () {
            expect(true).toBe(true);
        });

    });

});

