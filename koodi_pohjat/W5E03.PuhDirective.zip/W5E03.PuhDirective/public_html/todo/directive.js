
// ---------------------------------------
// Web-selainohjelmointi
// Tehtävä 5.3
// ---------------------------------------
//var OPISKELIJA = {
//    nimi: 'N.N.',
//    numero: '999999'
//};
// --------------------------------------- 

/* global PuhApp, Function */

PuhApp.directive('wsoBtn', function (WSO_BTN) {

    return {        
        // ...                
    };
});

