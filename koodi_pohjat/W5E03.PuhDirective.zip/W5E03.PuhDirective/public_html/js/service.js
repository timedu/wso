
/* global PuhApp */

PuhApp.service('Muistio', function () {

    // kopioi tämän tiedoston tilalle 
    // palvelu (service.js) edellisen tehtävän ratkaisusta

});
