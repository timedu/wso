
// ---------------------------------------
// Web-selainohjelmointi
// Tehtävä 5.1
// ---------------------------------------
var OPISKELIJA = {
    nimi: 'N.N.',
    numero: '999999'
};
// --------------------------------------- 

/* global muistio, PuhApp */

"use strict";

PuhApp.controller('PuhController', function ($scope) {

    var puh = new muistio.Model();

    // ...

});

