
// TiM

/* global Function, Element */

"use strict";

var muistio = muistio || {};

/**
 * Alustaa näkymän
 * @param {muistio.Model} model
 * @param {muistio.View} view
 */
muistio.initView = function (model, view) {

    view.asetaPaikka('#luettelo');
};

/**
 * Muodostaa näkymä-olion
 * @returns {muistio.View}
 */

muistio.View = function () {

    var paikka = '';
    var poista = function () {};

    this.asetaPaikka = function (s) {
        if (typeof s === 'string') {
            paikka = s;
        }
    };

    this.asetaPoista = function (f) {
        if (f instanceof Function) {
            poista = f;
        }
    };

    /*
     * näkymän hahmonnus 
     */

    this.hahmonna = function (nimi, numerot) {

        if(!paikka.length) {
            return;
        }

        var kohdeElementti = document.querySelector(paikka);
                
        if (!(kohdeElementti instanceof Element)) {
            return;
        }        
        
        kohdeElementti.innerHTML = '';

        var h2 = document.createElement('h2');
        h2.textContent = 'Henkilön ' + nimi + ' numerot';
        kohdeElementti.appendChild(h2);        
        
        var ul = document.createElement('ul');
        kohdeElementti.appendChild(ul);        

        numerot.forEach(function(numero){
            
            var button = document.createElement('button');            
            button.textContent = 'X';
            button.dataset.nimi = nimi;
            button.dataset.numero = numero;
            button.onclick = poista;

            var li = document.createElement('li');            
            li.textContent = numero;
            
            li.appendChild(button);            
            ul.appendChild(li);                        
        });        
    };

};

