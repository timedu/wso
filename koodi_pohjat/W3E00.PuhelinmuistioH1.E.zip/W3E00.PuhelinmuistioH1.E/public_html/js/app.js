
"use strict";

var muistio = muistio || {};

window.onload = function() {
  
    var model = new muistio.Model();   
    var view = new muistio.View();

    muistio.initView(model, view);
    muistio.initController(model, view);        
};
