
// TiM

"use strict";

var muistio = muistio || {};

muistio.initController = function(model, view) {
    
    /**
     * Etsii henkilön numerot puhelinmusitiosta
     */    
    
    document.querySelector('#etsi').onclick = function () {

        var nimi = document.querySelector('#nimi').value.trim();

        if (!!nimi.length) {
            view.hahmonna(nimi, model.annaNumerot(nimi));            
        }
    };

    /**
     * Lisää henkiön numero puhelinmuistion
     */

    document.querySelector('#lisaa').onclick = function () {

        var nimi = document.querySelector('#nimi').value.trim();
        var numero = document.querySelector('#numero').value.trim();

        if (!!nimi.length && !!numero.length) {
            model.lisaaNumero(nimi, numero);
            view.hahmonna(nimi, model.annaNumerot(nimi));            
        }
    };        
        
    /**
     * Poistaa numeron puhelinmuistiosta
     * @param {Event} event 
     */
    view.asetaPoista(function (event) {
        
        var nimi = event.target.dataset.nimi;
        var numero = event.target.dataset.numero;
        
        model.poistaNumero(nimi, numero);
        view.hahmonna(nimi, model.annaNumerot(nimi));
    });
            
};


