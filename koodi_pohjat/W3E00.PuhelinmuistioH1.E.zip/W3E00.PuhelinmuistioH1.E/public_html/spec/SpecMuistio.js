
/* global expect, muistio */

describe('Toiminta käyttöliittymän kautta:', function () {

    beforeEach(function () {

        setFixtures('\
        <div id="lomake"> \
            <label>Nimi: <input id="nimi"/></label>\
            <br/>\
            <label>Puhelinnumero: <input id="numero"/></label>\
            <br/>\
            <button id="etsi">Etsi</button>\
            <button id="lisaa">Lisää</button>\
        </div>\
              \
        <div id="luettelo"></div>');

        var model = new muistio.Model();
        var view = new muistio.View();

        muistio.initView(model, view);
        muistio.initController(model, view);
    });

    /*
     * Testidata
     * ----------------------------------------------
     */

    var nimi_1 = 'Homer';
    var numero_11 = '044-33669933';
    var numero_12 = '231';

    var nimi_2 = 'Bart';
    var numero_21 = '1111';

    var nimi_eioo = 'Ned';
    var numero_eioo = '333';

    /*
     * Numeroiden lisäys
     * ----------------------------------------------
     */

    it('esittää lisäyksen jälkeen henkilön nimen ja numeron sivulla', function () {

        $('#nimi').val(nimi_1);
        $('#numero').val(numero_11);
        $('#lisaa').click();

        expect($('#luettelo h2').text()).toContain(nimi_1);
        expect($('#luettelo li').length).toEqual(1);
        expect($('#luettelo li').text().substr(0, numero_11.length)).toEqual(numero_11);
    });

    it('ei esitä henkilölle samoja numeroita', function () {

        $('#nimi').val(nimi_1);
        $('#numero').val(numero_11);
        $('#lisaa').click();
        $('#lisaa').click();

        expect($('#luettelo h2').text()).toContain(nimi_1);
        expect($('#luettelo li').length).toEqual(1);
        expect($('#luettelo li').text().substr(0, numero_11.length)).toEqual(numero_11);
    });

    it('esittää lisäysten jälkeen henkilöllä useita eri numeroita', function () {

        $('#nimi').val(nimi_1);
        $('#numero').val(numero_11);
        $('#lisaa').click();

        $('#numero').val(numero_12);
        $('#lisaa').click();

        expect($('#luettelo li').length).toEqual(2);
        expect($('#luettelo li').first().text().substr(0, numero_11.length)).toEqual(numero_11);
        expect($('#luettelo li').last().text().substr(0, numero_12.length)).toEqual(numero_12);
    });

    it('ei esitä henkilölle toiselle henkilölle lisättyä numeroa', function () {

        $('#nimi').val(nimi_1);
        $('#numero').val(numero_11);
        $('#lisaa').click();

        $('#nimi').val(nimi_2);
        $('#etsi').click();

        expect($('#luettelo li').length).toEqual(0);
    });

    it('esitää useille henkilöille lisättyjä numeroita', function () {

        // numeroita henkilölle 1

        $('#nimi').val(nimi_1);
        $('#numero').val(numero_11);
        $('#lisaa').click();

        $('#nimi').val(nimi_1);
        $('#numero').val(numero_12);
        $('#lisaa').click();

        // numeroita henkilölle 2

        $('#nimi').val(nimi_2);
        $('#numero').val(numero_21);
        $('#lisaa').click();

        // henkilön 1 numerot esille

        $('#nimi').val(nimi_1);
        $('#etsi').click();

        expect($('#luettelo li').length).toEqual(2);
        expect($('#luettelo li').first().text().substr(0, numero_11.length)).toEqual(numero_11);
        expect($('#luettelo li').last().text().substr(0, numero_12.length)).toEqual(numero_12);

        // henkilön 2 numerot esille

        $('#nimi').val(nimi_2);
        $('#etsi').click();

        expect($('#luettelo li').length).toEqual(1);
        expect($('#luettelo li').text().substr(0, numero_21.length)).toEqual(numero_21);
    });

    /*
     * Numeroiden poisto
     * ----------------------------------------------
     */

    it('ei esitä henkilöltä poistettuja numeroita', function () {

        // lisätään henkilölle numero

        $('#nimi').val(nimi_1);
        $('#numero').val(numero_11);
        $('#lisaa').click();

        // lisätään henkilölle toinen numero

        $('#nimi').val(nimi_1);
        $('#numero').val(numero_12);
        $('#lisaa').click();

        // käyttöliittymässä on kaksi numeroa

        expect($('#luettelo li').length).toEqual(2);

        // poistetaan ensimmäinen numeto
        $('#luettelo li:first-child button').click();

        // toinen numero jää käyttöliittymään
        expect($('#luettelo li').length).toEqual(1);
        expect($('#luettelo li').text().substr(0, numero_12.length)).toEqual(numero_12);

        // poistetaan toinenkin numero
        $('#luettelo li:first-child button').click();

        // käyttöliittymässä ei ole numeroita
        expect($('#luettelo li').length).toEqual(0);

        // haetaan henkilön numerot
        $('#nimi').val(nimi_1);
        $('#etsi').click();

        // käyttöliittymässä ei ole numeroita
        expect($('#luettelo li').length).toEqual(0);

    });

    it('esittää henkilölle lisätyn numeron, \
vaikka se on poistettu toiselta henkilöltä', function () {

        // lisätään henkilölle 1 numero
        
        $('#nimi').val(nimi_1);
        $('#numero').val(numero_11);
        $('#lisaa').click();

        // lisätään henkilölle 2 numero
        
        $('#nimi').val(nimi_2);
        $('#numero').val(numero_11);
        $('#lisaa').click();

        // haetaan henkilön 1 numerot
        
        $('#nimi').val(nimi_1);
        $('#etsi').click();

        //  poistetaan henkilön 1 numero
        
        $('#luettelo li:first-child button').click();

        // numero ei ole käyttöliittymässä
        
        expect($('#luettelo li').length).toEqual(0);

        // haetaan henkilön 2 numerot
        
        $('#nimi').val(nimi_2);
        $('#etsi').click();

        // numero on käyttöliittymässä
        
        expect($('#luettelo li').length).toEqual(1);

    });

});