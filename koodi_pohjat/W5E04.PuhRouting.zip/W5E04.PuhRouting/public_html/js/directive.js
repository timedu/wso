

/* global PuhApp, Function */

PuhApp.directive('wsoBtn', function (WSO_BTN) {

    return {
        
        // kopioi tämän tiedoston tilalle
        // tehtävän 5.3 ratkaisusta directive.js
        
    };
});