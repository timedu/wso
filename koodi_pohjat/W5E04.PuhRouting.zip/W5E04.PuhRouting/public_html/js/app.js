
var PuhApp = angular.module('PuhApp', ['ngRoute']);

// wso-btn -direktiivin käyttämät painikkeiden otsikot
PuhApp.constant('WSO_BTN', {
    add: 'Lisää',
    remove: 'Poista',
    cancel: 'Peruuta'
});

// Muistio-palvelun datan alustus
PuhApp.value('init_data', {
    bart: ['111', '222', '333'],
    ned: ['444', '555']
});

