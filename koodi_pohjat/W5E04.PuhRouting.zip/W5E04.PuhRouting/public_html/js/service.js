

/* global PuhApp */

PuhApp.service('Muistio', function (init_data) {

    // kopioi tämän tiedoston tilalle
    // tehtävän 5.3 ratkaisusta service.js
    
    // voi halutessasi injektoida palveluun
    // lähtödataa (init_data), joka on määritelty
    // tiedostossa app.js

});
