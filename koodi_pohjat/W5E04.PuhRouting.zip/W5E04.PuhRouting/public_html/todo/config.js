
"use strict";

PuhApp.config(function ($routeProvider) {

    // ...
    
});

