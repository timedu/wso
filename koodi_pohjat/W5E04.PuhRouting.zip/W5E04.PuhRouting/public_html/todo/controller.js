
/* global PuhApp */

"use strict";

PuhApp.controller('PuhController', function ($scope, Muistio, $routeParams) {

    // ...
    
});


PuhApp.controller('AddController', function ($scope, Muistio, $location, $routeParams) {

    // ...

});


PuhApp.controller('RemoveController', function ($scope, Muistio, $location, $routeParams) {

    // ...

});

