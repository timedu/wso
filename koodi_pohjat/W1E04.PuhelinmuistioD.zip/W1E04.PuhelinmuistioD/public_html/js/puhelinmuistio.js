

"use strict";

/*
 * Tehtävä 1.4 Puhelinmuistio
 * 
 * Nimi: 
 * OpNro: 
 */


var hatanumerot = {
    poliisi: [112],
    sos: [112, 911]
};

var Puhelinmuistio;

