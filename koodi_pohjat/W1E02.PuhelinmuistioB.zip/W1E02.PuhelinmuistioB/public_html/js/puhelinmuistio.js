
"use strict";

/*
 * Tehtävä 1.2 Puhelinmuistio (moduuli)
 *
 * Nimi: 
 * OpNro:
 */

