
"use strict";

/*
 * Tehtävä 1.1 Puhelinmuistio (olio)
 * 
 * Nimi: 
 * OpNro:
 */


