
/* global expect, Function, Puhelinmuistio */

describe('Puhelinmuistion rakenne:', function () {

    it('sisältää Puhelinmuisto -muodostinfunktion', function () {
        expect(Puhelinmuistio instanceof Function).toBeTruthy();
    });

    it('Puhelinmuistiolla on lisaaNumero -metodi', function () {
        expect(Puhelinmuistio.prototype.lisaaNumero instanceof Function).toBeTruthy();
    });

    it('Puhelinmuistiolla on annaNumerot -metodi', function () {
        expect(Puhelinmuistio.prototype.annaNumerot instanceof Function).toBeTruthy();
    });

    it('Puhelinmuistiolla on poistaNumero -metodi', function () {
        expect(Puhelinmuistio.prototype.poistaNumero instanceof Function).toBeTruthy();
    });

    it('muodostimen prototyyppi-attribuutilla ei ole metodien lisäksi muita ominaisuuksia', function () {                
        expect(Object.keys(Puhelinmuistio.prototype).length).toEqual(3);
    });

    var muistio = new Puhelinmuistio();

    it('muistio-oliolla on attribuuttina _henkilot -olio', function () {        
        expect(muistio.hasOwnProperty('_henkilot')).toBeTruthy();
        expect(muistio._henkilot.constructor).toBe(Object);
    });

    it('muistio-oliolla ei ole attribuutin lisäksi muita ominaisuuksia', function () {                
        expect(Object.keys(muistio).length).toEqual(1);
    });
            
});
