
// ---------------------------------------
// Web-selainohjelmointi
// Tehtävä 4.1
// ---------------------------------------
var OPISKELIJA = {
    nimi: 'N.N.',
    numero: '999999'
};
// --------------------------------------- 

var BondApp = angular.module('BondApp', []);

BondApp.controller('BondController', function ($scope) {


});
