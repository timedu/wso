
// 
// Web-selainohjelmointi
// Tehtävä 7.4
// 
var OPISKELIJA = {
    nimi: 'N.N.',
    numero: '999999'
};
//  

/* global CalcApp, Window */

CalcApp.service('LogService', function (WEBSOCKET_URI) {

    // ...

    this.log = function (data) {
        
        // ...

    };

});

