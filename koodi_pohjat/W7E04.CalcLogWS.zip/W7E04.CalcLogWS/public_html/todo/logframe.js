
// 
// Web-selainohjelmointi
// Tehtävä 7.4
// 
var OPISKELIJA = {
    nimi: 'N.N.',
    numero: '999999'
};
//  

var websocket = parent['CalcApp'].websocket;

if(!websocket) {
    console.log('logframe: websocket ei ole käytettävissä');      
}; 

function createLogElement(logText) {  
    
    var logItems = document.querySelector('#log');   
    var logItem = document.createElement('div');
    logItem.textContent = logText;    
    logItems.insertBefore(logItem, logItems.firstChild);
}

// ..

