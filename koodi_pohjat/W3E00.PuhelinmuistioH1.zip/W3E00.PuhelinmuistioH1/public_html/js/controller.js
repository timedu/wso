
"use strict";

var muistio = muistio || {};

muistio.initController = function(model, view) {
    
    /**
     * Etsii henkilön numerot puhelinmusitiosta
     */    
    
    document.querySelector('#etsi').onclick = function () {


    };

    /**
     * Lisää henkiön numero puhelinmuistion
     */

    document.querySelector('#lisaa').onclick = function () {


    };        
        
    /**
     * Poistaa numeron puhelinmuistiosta
     * @param {Event} event 
     */
    view.asetaPoista(function (event) {
        

    });
            
};


