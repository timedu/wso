
/* global Function, Element */

"use strict";

var muistio = muistio || {};

/**
 * Alustaa näkymän
 * @param {muistio.Model} model
 * @param {muistio.View} view
 */
muistio.initView = function (model, view) {

    view.asetaPaikka('#luettelo');
};

/**
 * Muodostaa näkymä-olion
 * @returns {muistio.View}
 */

muistio.View = function () {

    var paikka = '';
    var poista = function () {};

    this.asetaPaikka = function (s) {
        
    };

    this.asetaPoista = function (f) {

    };

    /*
     * näkymän hahmonnus 
     */

    this.hahmonna = function (nimi, numerot) {

    };

};

