

/* global muistio, expect, Function */

describe('Puhelinmuistio - Model:', function () {

    /*
     * Testidata
     * ----------------------------------------------
     */

    var nimi_1 = 'homer';
    var numero_11 = '044-33669933';
    var numero_12 = '231';

    var nimi_2 = 'bart';
    var numero_21 = '1111';

    var nimi_eioo = 'ned';
    var numero_eioo = '333';

    var model;

    beforeEach(function () {
        model = new muistio.Model();
    });

    /*
     * Numeroiden lisäys
     * ----------------------------------------------
     */

    it('lisää numeron henkilölle', function () {

        model.lisaaNumero(nimi_1, numero_11);

        expect(model.annaNumerot(nimi_1).length).toEqual(1);
        expect(model.annaNumerot(nimi_1)).toContain(numero_11);
    });

    it('ei lisää samaa numeroa kahteen kertaan', function () {

        model.lisaaNumero(nimi_1, numero_11);
        model.lisaaNumero(nimi_1, numero_11);

        expect(model.annaNumerot(nimi_1).length).toEqual(1);
    });

    it('lisää henkilölle useita numeroita', function () {

        model.lisaaNumero(nimi_1, numero_11);
        model.lisaaNumero(nimi_1, numero_12);

        expect(model.annaNumerot(nimi_1).length).toEqual(2);
        expect(model.annaNumerot(nimi_1)).toContain(numero_11);
        expect(model.annaNumerot(nimi_1)).toContain(numero_12);
    });

    it('ei lisää henkilön numeroa toiselle henkilölle', function () {

        model.lisaaNumero(nimi_1, numero_11);

        expect(model.annaNumerot(nimi_2).length).toEqual(0);
    });


    it('lisää numeroita monelle henkilölle', function () {

        model.lisaaNumero(nimi_1, numero_11);
        model.lisaaNumero(nimi_1, numero_12);
        model.lisaaNumero(nimi_2, numero_21);

        expect(model.annaNumerot(nimi_1).length).toEqual(2);
        expect(model.annaNumerot(nimi_1)).toContain(numero_11);
        expect(model.annaNumerot(nimi_1)).toContain(numero_12);

        expect(model.annaNumerot(nimi_2).length).toEqual(1);
        expect(model.annaNumerot(nimi_2)).toContain(numero_21);
    });

    /*
     * Numeroiden poisto
     * ----------------------------------------------
     */

    it('ei poista numeroa, jos poiston hakuehto (nimi) ei toteudu', function () {

        model.lisaaNumero(nimi_1, numero_11);
        model.lisaaNumero(nimi_1, numero_12);

        model.poistaNumero(nimi_eioo, numero_12);

        expect(model.annaNumerot(nimi_1).length).toEqual(2);
        expect(model.annaNumerot(nimi_1)).toContain(numero_12);
    });

    it('ei poista numeroa, jos poiston hakuehto (numero) ei toteudu', function () {

        model.lisaaNumero(nimi_1, numero_11);
        model.lisaaNumero(nimi_1, numero_12);

        model.poistaNumero(nimi_1, numero_eioo);

        expect(model.annaNumerot(nimi_1).length).toEqual(2);
        expect(model.annaNumerot(nimi_1)).toContain(numero_11);
        expect(model.annaNumerot(nimi_1)).toContain(numero_12);
    });

    it('poistaa numeron toteutuvilla hakuehdoilla', function () {

        model.lisaaNumero(nimi_1, numero_11);
        model.lisaaNumero(nimi_1, numero_12);
        model.poistaNumero(nimi_1, numero_12);

        expect(model.annaNumerot(nimi_1).length).toEqual(1);
        expect(model.annaNumerot(nimi_1)).toContain(numero_11);
        expect(model.annaNumerot(nimi_1)).not.toContain(numero_12);
    });

    it('poistaa viimeisenkin numeron muistiosta', function () {

        model.lisaaNumero(nimi_1, numero_11);
        model.lisaaNumero(nimi_1, numero_12);
        model.poistaNumero(nimi_1, numero_12);
        model.poistaNumero(nimi_1, numero_11);

        expect(model.annaNumerot(nimi_1).length).toEqual(0);
    });

    /*
     * Numeroiden luku
     * ----------------------------------------------
     */

    it('palauttaa luettelon, jonka kautta ei voi lisätä numeroa muistioon', function () {

        model.lisaaNumero(nimi_1, numero_11);
        model.annaNumerot(nimi_1).push(numero_12);

        expect(model.annaNumerot(nimi_1).length).toEqual(1);
        expect(model.annaNumerot(nimi_1)).not.toContain(numero_12);
    });

});



