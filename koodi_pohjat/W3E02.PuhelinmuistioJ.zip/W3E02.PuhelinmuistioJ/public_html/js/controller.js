
"use strict";

var muistio = muistio || {};

muistio.initController = function(model, view) {
    
    /**
     * Etsii henkilön numerot puhelinmusitiosta
     */
    
    // ...
    
    /**
     * Lisää henkiön numero puhelinmuistion
     */
    
    // ...
            
    /**
     * Poistaa numeron puhelinmuistiosta
     * @param {Event} event 
     */
    
    // ...
    
};


