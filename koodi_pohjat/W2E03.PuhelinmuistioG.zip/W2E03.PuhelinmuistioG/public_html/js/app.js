
"use strict";

/* global muistio */

var muistio = muistio || {};

muistio.init = function () {


        
};

window.addEventListener('load', muistio.init);
