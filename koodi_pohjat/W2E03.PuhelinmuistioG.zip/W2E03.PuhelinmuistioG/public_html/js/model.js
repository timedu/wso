
/* global Function */

"use strict";

var muistio = muistio || {};

/*
 * +------------------------------------+
 * | MODEL                              |
 * +------------------------------------+
 * | - henkilot = {}                    |                      
 * +------------------------------------+
 * | + annaNumerot(nimi)                |
 * | + lisaaNumero(nimi, numero)        |
 * | + poistaNumero(nimi, numero)       |
 * | + asetaTarkkailija(funktio)        |
 * | - suoritaTarkkailija(nimi)         |
 * +------------------------------------+
 */

muistio.Model = function () {



};

