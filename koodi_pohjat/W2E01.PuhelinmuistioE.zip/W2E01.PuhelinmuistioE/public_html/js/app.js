
"use strict";

/* global muistio */

var muistio = muistio || {};

muistio.init = function () {

    // muodostetaan model, view ja controller

    var view = new muistio.View();
    var model = new muistio.Model(view);
    var controller = new muistio.Controller(model);

    // näkymän käsittelemät kohdat html-dokumentissa

    var spanNimi = document.querySelector('#luettelo h2 span');
    var ulNumerot = document.querySelector('#luettelo ul');

    view.asetaSpanNimi(spanNimi);
    view.asetaUlNumerot(ulNumerot);

    // syötekentät, joista kontrolleri poimii tiedot

    var inputNimi = document.getElementById('nimi');
    var inputNumero = document.getElementById('numero');

    controller.asetaNimiInput(inputNimi);
    controller.asetaNumeroInput(inputNumero);

    // dokumentin nappien click tapahtumien käsitelijät

    var buttonEtsi = document.getElementById('etsi');
    var buttonLisaa = document.getElementById('lisaa');

    buttonEtsi.onclick = controller.haeNumerot;
    buttonLisaa.onclick = controller.lisaaNumero;

    // näkymä rakentaa ajon aikana poisto-nappeja ja määrittelee
    // niiden click-tapahtumien käsittelijäksi tässä parametrina 
    // annetun funktion

    view.asetaPoistonKasittelija(controller.poistaNumero);
};

window.addEventListener('load', muistio.init);
