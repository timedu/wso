
/* global Function */

"use strict";

var muistio = muistio || {};

/*
 * +------------------------------------+
 * | MODEL                              |
 * +------------------------------------+
 * | - view                             |                      
 * | - henkilot = {}                    |                      
 * +------------------------------------+
 * | + annaNumerot(nimi)                |
 * | + lisaaNumero(nimi, numero)        |
 * | + poistaNumero(nimi, numero)       |
 * +------------------------------------+
 */

muistio.Model = function (view) {

    //

};

/*
 * +------------------------------------+
 * | VIEW                               |
 * +------------------------------------+
 * | - spanNimi                         |
 * | - ulNumerot                        |
 * | - functionPoistaNumero             |
 * +------------------------------------+
 * | + asetaSpanNimi(elementti)         |
 * | + asetaUlNumerot(elementti)        |
 * | + asetaPoistonKasittelija(funktio) |
 * | + paivita(nimi, numerot)           |
 * | - esitaNumero(nimi, numero)        |
 * | - poistaNumero(event)              |
 * +------------------------------------+
 */

muistio.View = function () {

    // viittattavat dokumentin elementit

    var spanNimi = null;
    var ulNumerot = null;

    // funktio, jota kutsutaan klikattaessa poista-nappia
    // (arvo asetetaan ao.metodilla)

    var functionPoistaNumero = null;

    //
};

/*
 * +------------------------------------+
 * | CONTROLLER                         |
 * +------------------------------------+
 * | - model                            |
 * | - inputNimi                        |
 * | - inputNumero                      |
 * +------------------------------------+
 * | + asetaNimiInput(elementti)        |
 * | + asetaNumeroInput(elementti)      |
 * | + haeNumerot()                     |
 * | + lisaaNumero()                    |
 * | + poistaNumero(e)                  |
 * +------------------------------------+
 */

muistio.Controller = function (model) {

    var inputNimi;
    var inputNumero;

    //
    
};

