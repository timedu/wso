 
/* global CalcApp */

CalcApp.service('CalcService', function () {

    this.calc = function (syote, done) {

        var operandi_1 = Math.round(parseFloat(syote.operandi_1));
        var operandi_2 = Math.round(parseFloat(syote.operandi_2));

        var operaattori = (typeof syote.operaattori === 'string'
                && syote.operaattori.length === 1
                && "+-*/".indexOf(syote.operaattori) >= 0) ? syote.operaattori : '?';

        var lauseke = operandi_1 + ' ' + operaattori + ' ' + operandi_2;

        var tulos = Math.round(eval(lauseke));

        var laskutoimitus = lauseke +
                ((typeof tulos === 'number') &&
                        !isNaN(tulos) && isFinite(tulos) ? ' = ' + tulos : '');

        done(laskutoimitus);

    };

});

