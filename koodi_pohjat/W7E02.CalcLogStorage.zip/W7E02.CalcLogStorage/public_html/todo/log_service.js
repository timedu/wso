
// 
// Web-selainohjelmointi
// Tehtävä 7.2
// 
var OPISKELIJA = {
    nimi: 'N.N.',
    numero: '999999'
};
//  

/* global CalcApp */

CalcApp.service('LogService', function (STORAGE_KEY) {
    
    this.log = function(data) {
        // ...        
    };
    
});

