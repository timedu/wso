
// 
// Web-selainohjelmointi
// Tehtävä 7.2
// 
var OPISKELIJA = {
    nimi: 'N.N.',
    numero: '999999'
};
//  

var STORAGE_KEY = 'wso-laskutoimitus';

function createLogElement(logText) {  
    
    var logItems = document.querySelector('#log');   
    var logItem = document.createElement('div');
    logItem.textContent = logText;    
    logItems.insertBefore(logItem, logItems.firstChild);
}

// ...

